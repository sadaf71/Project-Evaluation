### Evaluation Project 3 HR Analytics Project- Understanding the Attrition in HR
By: Sadaf Shamim

Batch: DS2307

#### Problem Statement:
Every year a lot of companies hire a number of employees. The companies invest time and money in training those employees, not just this but there are training programs within the companies for their existing employees as well. The aim of these programs is to increase the effectiveness of their employees. But where HR Analytics fit in this? and is it just about improving the performance of employees?

#### HR Analytics:
Human resource analytics (HR analytics) is an area in the field of analytics that refers to applying analytic processes to the human resource department of an organization in the hope of improving employee performance and therefore getting a better return on investment. HR analytics does not just deal with gathering data on employee efficiency. Instead, it aims to provide insight into each process by gathering data and then using it to make relevant decisions about how to improve these processes.

#### Attrition in HR:
Attrition in human resources refers to the gradual loss of employees overtime. In general, relatively high attrition is problematic for companies. HR professionals often assume a leadership role in designing company compensation programs, work culture, and motivation systems that help the organization retain top employees.

##### How does Attrition affect companies? and how does HR Analytics help in analyzing attrition? We will discuss the first question here and for the second question, we will write the code and try to understand the process step by step.

#### Attrition affecting Companies:
A major problem in high employee attrition is its cost to an organization. Job postings, hiring processes, paperwork, and new hire training are some of the common expenses of losing employees and replacing them. Additionally, regular employee turnover prohibits your organization from increasing its collective knowledge base and experience over time. This is especially concerning if your business is customer-facing, as customers often prefer to interact with familiar people. Errors and issues are more likely if you constantly have new workers.

##### Note: You can find the dataset in the link below.

Downlaod Files:

https://github.com/dsrscientist/IBM_HR_Attrition_Rate_Analytics


```python
import pandas as pd # for data wrangling purpose
import numpy as np # Basic computation library
import seaborn as sns # For Visualization 
import matplotlib.pyplot as plt # ploting package
%matplotlib inline
import warnings # Filtering warnings
warnings.filterwarnings('ignore')
```


```python
df=pd.read_csv('D:\\New folder\\WA_Fn-UseC_-HR-Employee-Attrition.csv')

```


```python
print('No of Rows:',df.shape[0])
print('No of Columns:',df.shape[1])
pd.set_option('display.max_columns', None) # This will enable us to see truncated columns
df.head()
```

    No of Rows: 1470
    No of Columns: 35
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Attrition</th>
      <th>BusinessTravel</th>
      <th>DailyRate</th>
      <th>Department</th>
      <th>DistanceFromHome</th>
      <th>Education</th>
      <th>EducationField</th>
      <th>EmployeeCount</th>
      <th>EmployeeNumber</th>
      <th>EnvironmentSatisfaction</th>
      <th>Gender</th>
      <th>HourlyRate</th>
      <th>JobInvolvement</th>
      <th>JobLevel</th>
      <th>JobRole</th>
      <th>JobSatisfaction</th>
      <th>MaritalStatus</th>
      <th>MonthlyIncome</th>
      <th>MonthlyRate</th>
      <th>NumCompaniesWorked</th>
      <th>Over18</th>
      <th>OverTime</th>
      <th>PercentSalaryHike</th>
      <th>PerformanceRating</th>
      <th>RelationshipSatisfaction</th>
      <th>StandardHours</th>
      <th>StockOptionLevel</th>
      <th>TotalWorkingYears</th>
      <th>TrainingTimesLastYear</th>
      <th>WorkLifeBalance</th>
      <th>YearsAtCompany</th>
      <th>YearsInCurrentRole</th>
      <th>YearsSinceLastPromotion</th>
      <th>YearsWithCurrManager</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>41</td>
      <td>Yes</td>
      <td>Travel_Rarely</td>
      <td>1102</td>
      <td>Sales</td>
      <td>1</td>
      <td>2</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>Female</td>
      <td>94</td>
      <td>3</td>
      <td>2</td>
      <td>Sales Executive</td>
      <td>4</td>
      <td>Single</td>
      <td>5993</td>
      <td>19479</td>
      <td>8</td>
      <td>Y</td>
      <td>Yes</td>
      <td>11</td>
      <td>3</td>
      <td>1</td>
      <td>80</td>
      <td>0</td>
      <td>8</td>
      <td>0</td>
      <td>1</td>
      <td>6</td>
      <td>4</td>
      <td>0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>49</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>279</td>
      <td>Research &amp; Development</td>
      <td>8</td>
      <td>1</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>Male</td>
      <td>61</td>
      <td>2</td>
      <td>2</td>
      <td>Research Scientist</td>
      <td>2</td>
      <td>Married</td>
      <td>5130</td>
      <td>24907</td>
      <td>1</td>
      <td>Y</td>
      <td>No</td>
      <td>23</td>
      <td>4</td>
      <td>4</td>
      <td>80</td>
      <td>1</td>
      <td>10</td>
      <td>3</td>
      <td>3</td>
      <td>10</td>
      <td>7</td>
      <td>1</td>
      <td>7</td>
    </tr>
    <tr>
      <th>2</th>
      <td>37</td>
      <td>Yes</td>
      <td>Travel_Rarely</td>
      <td>1373</td>
      <td>Research &amp; Development</td>
      <td>2</td>
      <td>2</td>
      <td>Other</td>
      <td>1</td>
      <td>4</td>
      <td>4</td>
      <td>Male</td>
      <td>92</td>
      <td>2</td>
      <td>1</td>
      <td>Laboratory Technician</td>
      <td>3</td>
      <td>Single</td>
      <td>2090</td>
      <td>2396</td>
      <td>6</td>
      <td>Y</td>
      <td>Yes</td>
      <td>15</td>
      <td>3</td>
      <td>2</td>
      <td>80</td>
      <td>0</td>
      <td>7</td>
      <td>3</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>33</td>
      <td>No</td>
      <td>Travel_Frequently</td>
      <td>1392</td>
      <td>Research &amp; Development</td>
      <td>3</td>
      <td>4</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>5</td>
      <td>4</td>
      <td>Female</td>
      <td>56</td>
      <td>3</td>
      <td>1</td>
      <td>Research Scientist</td>
      <td>3</td>
      <td>Married</td>
      <td>2909</td>
      <td>23159</td>
      <td>1</td>
      <td>Y</td>
      <td>Yes</td>
      <td>11</td>
      <td>3</td>
      <td>3</td>
      <td>80</td>
      <td>0</td>
      <td>8</td>
      <td>3</td>
      <td>3</td>
      <td>8</td>
      <td>7</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>27</td>
      <td>No</td>
      <td>Travel_Rarely</td>
      <td>591</td>
      <td>Research &amp; Development</td>
      <td>2</td>
      <td>1</td>
      <td>Medical</td>
      <td>1</td>
      <td>7</td>
      <td>1</td>
      <td>Male</td>
      <td>40</td>
      <td>3</td>
      <td>1</td>
      <td>Laboratory Technician</td>
      <td>2</td>
      <td>Married</td>
      <td>3468</td>
      <td>16632</td>
      <td>9</td>
      <td>Y</td>
      <td>No</td>
      <td>12</td>
      <td>3</td>
      <td>4</td>
      <td>80</td>
      <td>1</td>
      <td>6</td>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.columns
```




    Index(['Age', 'Attrition', 'BusinessTravel', 'DailyRate', 'Department',
           'DistanceFromHome', 'Education', 'EducationField', 'EmployeeCount',
           'EmployeeNumber', 'EnvironmentSatisfaction', 'Gender', 'HourlyRate',
           'JobInvolvement', 'JobLevel', 'JobRole', 'JobSatisfaction',
           'MaritalStatus', 'MonthlyIncome', 'MonthlyRate', 'NumCompaniesWorked',
           'Over18', 'OverTime', 'PercentSalaryHike', 'PerformanceRating',
           'RelationshipSatisfaction', 'StandardHours', 'StockOptionLevel',
           'TotalWorkingYears', 'TrainingTimesLastYear', 'WorkLifeBalance',
           'YearsAtCompany', 'YearsInCurrentRole', 'YearsSinceLastPromotion',
           'YearsWithCurrManager'],
          dtype='object')




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1470 entries, 0 to 1469
    Data columns (total 35 columns):
     #   Column                    Non-Null Count  Dtype 
    ---  ------                    --------------  ----- 
     0   Age                       1470 non-null   int64 
     1   Attrition                 1470 non-null   object
     2   BusinessTravel            1470 non-null   object
     3   DailyRate                 1470 non-null   int64 
     4   Department                1470 non-null   object
     5   DistanceFromHome          1470 non-null   int64 
     6   Education                 1470 non-null   int64 
     7   EducationField            1470 non-null   object
     8   EmployeeCount             1470 non-null   int64 
     9   EmployeeNumber            1470 non-null   int64 
     10  EnvironmentSatisfaction   1470 non-null   int64 
     11  Gender                    1470 non-null   object
     12  HourlyRate                1470 non-null   int64 
     13  JobInvolvement            1470 non-null   int64 
     14  JobLevel                  1470 non-null   int64 
     15  JobRole                   1470 non-null   object
     16  JobSatisfaction           1470 non-null   int64 
     17  MaritalStatus             1470 non-null   object
     18  MonthlyIncome             1470 non-null   int64 
     19  MonthlyRate               1470 non-null   int64 
     20  NumCompaniesWorked        1470 non-null   int64 
     21  Over18                    1470 non-null   object
     22  OverTime                  1470 non-null   object
     23  PercentSalaryHike         1470 non-null   int64 
     24  PerformanceRating         1470 non-null   int64 
     25  RelationshipSatisfaction  1470 non-null   int64 
     26  StandardHours             1470 non-null   int64 
     27  StockOptionLevel          1470 non-null   int64 
     28  TotalWorkingYears         1470 non-null   int64 
     29  TrainingTimesLastYear     1470 non-null   int64 
     30  WorkLifeBalance           1470 non-null   int64 
     31  YearsAtCompany            1470 non-null   int64 
     32  YearsInCurrentRole        1470 non-null   int64 
     33  YearsSinceLastPromotion   1470 non-null   int64 
     34  YearsWithCurrManager      1470 non-null   int64 
    dtypes: int64(26), object(9)
    memory usage: 402.1+ KB
    


```python
# As we have 35 Columns Lets sort Columns by their datatype
df.columns.to_series().groupby(df.dtypes).groups
```




    {int64: ['Age', 'DailyRate', 'DistanceFromHome', 'Education', 'EmployeeCount', 'EmployeeNumber', 'EnvironmentSatisfaction', 'HourlyRate', 'JobInvolvement', 'JobLevel', 'JobSatisfaction', 'MonthlyIncome', 'MonthlyRate', 'NumCompaniesWorked', 'PercentSalaryHike', 'PerformanceRating', 'RelationshipSatisfaction', 'StandardHours', 'StockOptionLevel', 'TotalWorkingYears', 'TrainingTimesLastYear', 'WorkLifeBalance', 'YearsAtCompany', 'YearsInCurrentRole', 'YearsSinceLastPromotion', 'YearsWithCurrManager'], object: ['Attrition', 'BusinessTravel', 'Department', 'EducationField', 'Gender', 'JobRole', 'MaritalStatus', 'Over18', 'OverTime']}



### Comment :
- In this HR dataset we have 1470 rows and 35 columns.
- Non-null count is same for all Columns, so it seem that it contain No missing value. Still we need to perform Data integrity Check for null values in form of "-","NA" , any duplicate entry or error in Data.
- Out of 35 we have 9 features with Object datatypes and rest are int64 types
- Among all Numeric Variables 'Education','EnvironmentSatisfaction', 'JobInvolvement', 'JobSatisfaction', 'RelationshipSatisfaction', 'PerformanceRating', 'WorkLifeBalance' are ordinal variable. Unique range of all these ordinal Variable need to check.
- Here We have Target Variable 'Attrition'.


##### These Ordinal features come with the following label encoding:

- Education: 1- 'Below College' , 2 -'College', 3 -'Bachelor', 4- 'Master' ,5 -'Doctor'
- EnvironmentSatisfaction: 1- 'Low', 2- 'Medium', 3 -'High', 4- 'Very High'
- JobInvolvement: 1 -'Low', 2- 'Medium', 3- 'High', 4- 'Very High'
- JobSatisfaction: 1- 'Low', 2- 'Medium', 3- 'High', 4 -'Very High'
- PerformanceRating: 1- 'Low', 2- 'Average', 3 -'Good', 4- 'Excellent', 5- 'Outstanding'
- RelationshipSatisfaction: 1- 'Low', 2- 'Medium', 3- 'High', 4- 'Very High'
- WorkLifeBalance: 1- 'Bad', 2- 'Good', 3- 'Better', 4- 'Best'




## Statistical Analysis


- Before Going for Statistical exploration of data, first check integrity of data & Missing value

##### Data Integrity Check
- Since dataset is large, Let check for any entry which is repeated or duplicated in dataset.


```python
df.duplicated().sum()  # This will check the duplicate data for all columns.

```




    0



### Missing value check


```python
missing_values = df.isnull().sum().sort_values(ascending = False)
missing_values
```




    Age                         0
    StandardHours               0
    NumCompaniesWorked          0
    Over18                      0
    OverTime                    0
    PercentSalaryHike           0
    PerformanceRating           0
    RelationshipSatisfaction    0
    StockOptionLevel            0
    MonthlyIncome               0
    TotalWorkingYears           0
    TrainingTimesLastYear       0
    WorkLifeBalance             0
    YearsAtCompany              0
    YearsInCurrentRole          0
    YearsSinceLastPromotion     0
    MonthlyRate                 0
    MaritalStatus               0
    Attrition                   0
    EmployeeCount               0
    BusinessTravel              0
    DailyRate                   0
    Department                  0
    DistanceFromHome            0
    Education                   0
    EducationField              0
    EmployeeNumber              0
    JobSatisfaction             0
    EnvironmentSatisfaction     0
    Gender                      0
    HourlyRate                  0
    JobInvolvement              0
    JobLevel                    0
    JobRole                     0
    YearsWithCurrManager        0
    dtype: int64



### Comment:
- Luckily for us, there is no missing data! this will make it easier to work with the dataset.

Dataset doesnot contain Any duplicate entry, Missing Values.

### Statistical Matrix


```python
# Visualizing the statistics of the columns using heatmap.
plt.figure(figsize=(28,10))
sns.heatmap(df.describe(),linewidths = 0.1,fmt='0.1f',annot = True,cmap='PiYG')
```




    <AxesSubplot:>




    
![png](output_13_1.png)
    



```python
df.describe().T.round(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>mean</th>
      <th>std</th>
      <th>min</th>
      <th>25%</th>
      <th>50%</th>
      <th>75%</th>
      <th>max</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Age</th>
      <td>1470.0</td>
      <td>36.924</td>
      <td>9.135</td>
      <td>18.0</td>
      <td>30.00</td>
      <td>36.0</td>
      <td>43.00</td>
      <td>60.0</td>
    </tr>
    <tr>
      <th>DailyRate</th>
      <td>1470.0</td>
      <td>802.486</td>
      <td>403.509</td>
      <td>102.0</td>
      <td>465.00</td>
      <td>802.0</td>
      <td>1157.00</td>
      <td>1499.0</td>
    </tr>
    <tr>
      <th>DistanceFromHome</th>
      <td>1470.0</td>
      <td>9.193</td>
      <td>8.107</td>
      <td>1.0</td>
      <td>2.00</td>
      <td>7.0</td>
      <td>14.00</td>
      <td>29.0</td>
    </tr>
    <tr>
      <th>Education</th>
      <td>1470.0</td>
      <td>2.913</td>
      <td>1.024</td>
      <td>1.0</td>
      <td>2.00</td>
      <td>3.0</td>
      <td>4.00</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>EmployeeCount</th>
      <td>1470.0</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>1.0</td>
      <td>1.00</td>
      <td>1.0</td>
      <td>1.00</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>EmployeeNumber</th>
      <td>1470.0</td>
      <td>1024.865</td>
      <td>602.024</td>
      <td>1.0</td>
      <td>491.25</td>
      <td>1020.5</td>
      <td>1555.75</td>
      <td>2068.0</td>
    </tr>
    <tr>
      <th>EnvironmentSatisfaction</th>
      <td>1470.0</td>
      <td>2.722</td>
      <td>1.093</td>
      <td>1.0</td>
      <td>2.00</td>
      <td>3.0</td>
      <td>4.00</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>HourlyRate</th>
      <td>1470.0</td>
      <td>65.891</td>
      <td>20.329</td>
      <td>30.0</td>
      <td>48.00</td>
      <td>66.0</td>
      <td>83.75</td>
      <td>100.0</td>
    </tr>
    <tr>
      <th>JobInvolvement</th>
      <td>1470.0</td>
      <td>2.730</td>
      <td>0.712</td>
      <td>1.0</td>
      <td>2.00</td>
      <td>3.0</td>
      <td>3.00</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>JobLevel</th>
      <td>1470.0</td>
      <td>2.064</td>
      <td>1.107</td>
      <td>1.0</td>
      <td>1.00</td>
      <td>2.0</td>
      <td>3.00</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>JobSatisfaction</th>
      <td>1470.0</td>
      <td>2.729</td>
      <td>1.103</td>
      <td>1.0</td>
      <td>2.00</td>
      <td>3.0</td>
      <td>4.00</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>MonthlyIncome</th>
      <td>1470.0</td>
      <td>6502.931</td>
      <td>4707.957</td>
      <td>1009.0</td>
      <td>2911.00</td>
      <td>4919.0</td>
      <td>8379.00</td>
      <td>19999.0</td>
    </tr>
    <tr>
      <th>MonthlyRate</th>
      <td>1470.0</td>
      <td>14313.103</td>
      <td>7117.786</td>
      <td>2094.0</td>
      <td>8047.00</td>
      <td>14235.5</td>
      <td>20461.50</td>
      <td>26999.0</td>
    </tr>
    <tr>
      <th>NumCompaniesWorked</th>
      <td>1470.0</td>
      <td>2.693</td>
      <td>2.498</td>
      <td>0.0</td>
      <td>1.00</td>
      <td>2.0</td>
      <td>4.00</td>
      <td>9.0</td>
    </tr>
    <tr>
      <th>PercentSalaryHike</th>
      <td>1470.0</td>
      <td>15.210</td>
      <td>3.660</td>
      <td>11.0</td>
      <td>12.00</td>
      <td>14.0</td>
      <td>18.00</td>
      <td>25.0</td>
    </tr>
    <tr>
      <th>PerformanceRating</th>
      <td>1470.0</td>
      <td>3.154</td>
      <td>0.361</td>
      <td>3.0</td>
      <td>3.00</td>
      <td>3.0</td>
      <td>3.00</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>RelationshipSatisfaction</th>
      <td>1470.0</td>
      <td>2.712</td>
      <td>1.081</td>
      <td>1.0</td>
      <td>2.00</td>
      <td>3.0</td>
      <td>4.00</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>StandardHours</th>
      <td>1470.0</td>
      <td>80.000</td>
      <td>0.000</td>
      <td>80.0</td>
      <td>80.00</td>
      <td>80.0</td>
      <td>80.00</td>
      <td>80.0</td>
    </tr>
    <tr>
      <th>StockOptionLevel</th>
      <td>1470.0</td>
      <td>0.794</td>
      <td>0.852</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>1.0</td>
      <td>1.00</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>TotalWorkingYears</th>
      <td>1470.0</td>
      <td>11.280</td>
      <td>7.781</td>
      <td>0.0</td>
      <td>6.00</td>
      <td>10.0</td>
      <td>15.00</td>
      <td>40.0</td>
    </tr>
    <tr>
      <th>TrainingTimesLastYear</th>
      <td>1470.0</td>
      <td>2.799</td>
      <td>1.289</td>
      <td>0.0</td>
      <td>2.00</td>
      <td>3.0</td>
      <td>3.00</td>
      <td>6.0</td>
    </tr>
    <tr>
      <th>WorkLifeBalance</th>
      <td>1470.0</td>
      <td>2.761</td>
      <td>0.706</td>
      <td>1.0</td>
      <td>2.00</td>
      <td>3.0</td>
      <td>3.00</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>YearsAtCompany</th>
      <td>1470.0</td>
      <td>7.008</td>
      <td>6.127</td>
      <td>0.0</td>
      <td>3.00</td>
      <td>5.0</td>
      <td>9.00</td>
      <td>40.0</td>
    </tr>
    <tr>
      <th>YearsInCurrentRole</th>
      <td>1470.0</td>
      <td>4.229</td>
      <td>3.623</td>
      <td>0.0</td>
      <td>2.00</td>
      <td>3.0</td>
      <td>7.00</td>
      <td>18.0</td>
    </tr>
    <tr>
      <th>YearsSinceLastPromotion</th>
      <td>1470.0</td>
      <td>2.188</td>
      <td>3.222</td>
      <td>0.0</td>
      <td>0.00</td>
      <td>1.0</td>
      <td>3.00</td>
      <td>15.0</td>
    </tr>
    <tr>
      <th>YearsWithCurrManager</th>
      <td>1470.0</td>
      <td>4.123</td>
      <td>3.568</td>
      <td>0.0</td>
      <td>2.00</td>
      <td>3.0</td>
      <td>7.00</td>
      <td>17.0</td>
    </tr>
  </tbody>
</table>
</div>



### Comment :
- Minimum Empolyee Age is 18 and Maximum age of employee 60.
- Average distance from home is 9.1 KM. It means that most of employee travel atleast 18 KM in day from home to office.
- On Average performance Rating of employees is 3.163 with min value 3.0. This Means that performance of most of employee is 'Good'.This implies that Attrition of Employee with 'Outstanding' or 5 rating need to investigate.
- 50% of Employees has worked atleast 2 companies previously.
- For Monthly Income,Monthly Rate by looking at 50% and max column we can say outliers exist in this feature.
- By looking at Mean and Median we see that some of the features are skew in nature.
- For ordinal features statstical terminology of mean, median, std deviation doesnot make sense.
- StandardHours and EmployeeCount contain same value for all stastical parameter. It means they contain one unique value.

##### Lets do some Statistical Analysis. Start with target Variable.


```python
df['Attrition'].value_counts()
```




    No     1233
    Yes     237
    Name: Attrition, dtype: int64




```python
labels = 'Yes','No',
fig, ax = plt.subplots()
ax.pie(df['Attrition'].value_counts(),labels = labels,radius =2,autopct = '%2.2f%%',explode=[0.1,0.2], shadow=True,)
plt.show()
```


    
![png](output_17_0.png)
    


### Comment:
- 83.88% (1237 employees) Employees did not leave the organization while 16.12% (237 employees) did leave the organization making our dataset to be considered imbalanced since more people stay in the organization than they actually leave.



##### Before arrive at key questions which need to answer about HR Attrition, let try to gain some insight about individual features like distribution of different subcategories, different insight about Human Resource in company like education,job level, working domain.



#### Start with Enlisting Value counts & Sub-categories of different categorial features available
 


```python
Category=['Attrition', 'BusinessTravel', 'Department', 'EducationField',
          'Gender', 'JobRole', 'MaritalStatus', 'Over18', 'OverTime' ]
for i in Category:
    print(i)
    print(df[i].value_counts())
    print("="*100)
```

    Attrition
    No     1233
    Yes     237
    Name: Attrition, dtype: int64
    ====================================================================================================
    BusinessTravel
    Travel_Rarely        1043
    Travel_Frequently     277
    Non-Travel            150
    Name: BusinessTravel, dtype: int64
    ====================================================================================================
    Department
    Research & Development    961
    Sales                     446
    Human Resources            63
    Name: Department, dtype: int64
    ====================================================================================================
    EducationField
    Life Sciences       606
    Medical             464
    Marketing           159
    Technical Degree    132
    Other                82
    Human Resources      27
    Name: EducationField, dtype: int64
    ====================================================================================================
    Gender
    Male      882
    Female    588
    Name: Gender, dtype: int64
    ====================================================================================================
    JobRole
    Sales Executive              326
    Research Scientist           292
    Laboratory Technician        259
    Manufacturing Director       145
    Healthcare Representative    131
    Manager                      102
    Sales Representative          83
    Research Director             80
    Human Resources               52
    Name: JobRole, dtype: int64
    ====================================================================================================
    MaritalStatus
    Married     673
    Single      470
    Divorced    327
    Name: MaritalStatus, dtype: int64
    ====================================================================================================
    Over18
    Y    1470
    Name: Over18, dtype: int64
    ====================================================================================================
    OverTime
    No     1054
    Yes     416
    Name: OverTime, dtype: int64
    ====================================================================================================
    


```python
sns.set_palette('gist_rainbow_r')
plt.figure(figsize=(20,20), facecolor='white')
plotnumber =1
Category=['Attrition', 'BusinessTravel', 'Department', 'EducationField',
          'Gender', 'JobRole', 'MaritalStatus', 'Over18', 'OverTime' ]
for i in Category:
    if plotnumber <=9:
        ax = plt.subplot(3,3,plotnumber)
        sns.countplot(df[i])
        plt.xlabel(i,fontsize=20)
        plt.xticks(rotation=30)
    plotnumber+=1
plt.tight_layout()
plt.show()
```


    
![png](output_20_0.png)
    



```python
Ordinal=['Education','EnvironmentSatisfaction', 'JobInvolvement','JobSatisfaction',
          'RelationshipSatisfaction', 'PerformanceRating', 'WorkLifeBalance' ]
for i in Ordinal:
    print(i)
    print(df[i].value_counts())
    print("="*100)
```

    Education
    3    572
    4    398
    2    282
    1    170
    5     48
    Name: Education, dtype: int64
    ====================================================================================================
    EnvironmentSatisfaction
    3    453
    4    446
    2    287
    1    284
    Name: EnvironmentSatisfaction, dtype: int64
    ====================================================================================================
    JobInvolvement
    3    868
    2    375
    4    144
    1     83
    Name: JobInvolvement, dtype: int64
    ====================================================================================================
    JobSatisfaction
    4    459
    3    442
    1    289
    2    280
    Name: JobSatisfaction, dtype: int64
    ====================================================================================================
    RelationshipSatisfaction
    3    459
    4    432
    2    303
    1    276
    Name: RelationshipSatisfaction, dtype: int64
    ====================================================================================================
    PerformanceRating
    3    1244
    4     226
    Name: PerformanceRating, dtype: int64
    ====================================================================================================
    WorkLifeBalance
    3    893
    2    344
    4    153
    1     80
    Name: WorkLifeBalance, dtype: int64
    ====================================================================================================
    


```python
sns.set_palette('hsv')
plt.figure(figsize=(20,20), facecolor='white')
plotnumber =1
Ordinal=['Education','EnvironmentSatisfaction', 'JobInvolvement','JobSatisfaction',
          'RelationshipSatisfaction', 'PerformanceRating', 'WorkLifeBalance' ]
for i in Ordinal:
    if plotnumber <=9:
        ax = plt.subplot(3,3,plotnumber)
        sns.countplot(df[i])
        plt.xlabel(i,fontsize=20)
        plt.xticks(rotation=30)
    plotnumber+=1
plt.tight_layout()
plt.show()

```


    
![png](output_22_0.png)
    


### Education level of Man power available


```python
labels='Bachelor','Master','College','Below College','Doctor'
fig, ax = plt.subplots()
ax.pie(df['Education'].value_counts(),labels = labels,radius =2,autopct = '%3.2f%%',explode=[0.1,0.1,0.15,0.2,0.3], shadow=True,)
plt.show()
```


    
![png](output_24_0.png)
    


### Comment:
- More than 60 % employees educated at Masters & Bachelor. It interesting to find out in which department need this human resources.
- 30 % of Employees are highly educated which involves master and doctor degree.
- 39 % of Employees are graduate.
- Almost 19% Employees are educated upto college & 12% are below college.



###### Lets try to gain insight on to which department this Human Resource belong and education need of each department through visualization.


```python
df['Department'].value_counts()
```




    Research & Development    961
    Sales                     446
    Human Resources            63
    Name: Department, dtype: int64




```python
labels ='Research & Development','Sales','Human Resources'
fig,ax= plt.subplots()
ax.pie(df['Department'].value_counts(),labels=labels, radius=2,autopct= '%3.2f%%',explode=[0.1,0.15,0.2],shadow=True)
plt.show()
```


    
![png](output_27_0.png)
    



```python
pd.crosstab([df.Education],[df.Department], margins=True).style.background_gradient(cmap='summer_r')

```




<style type="text/css">
#T_5a521_row0_col0 {
  background-color: #f7fb66;
  color: #000000;
}
#T_5a521_row0_col1 {
  background-color: #e8f466;
  color: #000000;
}
#T_5a521_row0_col2 {
  background-color: #ebf566;
  color: #000000;
}
#T_5a521_row0_col3 {
  background-color: #eaf466;
  color: #000000;
}
#T_5a521_row1_col0, #T_5a521_row1_col2, #T_5a521_row1_col3 {
  background-color: #d5ea66;
  color: #000000;
}
#T_5a521_row1_col1 {
  background-color: #d6eb66;
  color: #000000;
}
#T_5a521_row2_col0 {
  background-color: #99cc66;
  color: #000000;
}
#T_5a521_row2_col1 {
  background-color: #a0d066;
  color: #000000;
}
#T_5a521_row2_col2 {
  background-color: #a6d266;
  color: #000000;
}
#T_5a521_row2_col3 {
  background-color: #a1d066;
  color: #000000;
}
#T_5a521_row3_col0 {
  background-color: #cce666;
  color: #000000;
}
#T_5a521_row3_col1 {
  background-color: #c2e066;
  color: #000000;
}
#T_5a521_row3_col2 {
  background-color: #bcde66;
  color: #000000;
}
#T_5a521_row3_col3 {
  background-color: #c0e066;
  color: #000000;
}
#T_5a521_row4_col0, #T_5a521_row4_col1, #T_5a521_row4_col2, #T_5a521_row4_col3 {
  background-color: #ffff66;
  color: #000000;
}
#T_5a521_row5_col0, #T_5a521_row5_col1, #T_5a521_row5_col2, #T_5a521_row5_col3 {
  background-color: #008066;
  color: #f1f1f1;
}
</style>
<table id="T_5a521">
  <thead>
    <tr>
      <th class="index_name level0" >Department</th>
      <th id="T_5a521_level0_col0" class="col_heading level0 col0" >Human Resources</th>
      <th id="T_5a521_level0_col1" class="col_heading level0 col1" >Research & Development</th>
      <th id="T_5a521_level0_col2" class="col_heading level0 col2" >Sales</th>
      <th id="T_5a521_level0_col3" class="col_heading level0 col3" >All</th>
    </tr>
    <tr>
      <th class="index_name level0" >Education</th>
      <th class="blank col0" >&nbsp;</th>
      <th class="blank col1" >&nbsp;</th>
      <th class="blank col2" >&nbsp;</th>
      <th class="blank col3" >&nbsp;</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th id="T_5a521_level0_row0" class="row_heading level0 row0" >1</th>
      <td id="T_5a521_row0_col0" class="data row0 col0" >5</td>
      <td id="T_5a521_row0_col1" class="data row0 col1" >115</td>
      <td id="T_5a521_row0_col2" class="data row0 col2" >50</td>
      <td id="T_5a521_row0_col3" class="data row0 col3" >170</td>
    </tr>
    <tr>
      <th id="T_5a521_level0_row1" class="row_heading level0 row1" >2</th>
      <td id="T_5a521_row1_col0" class="data row1 col0" >13</td>
      <td id="T_5a521_row1_col1" class="data row1 col1" >182</td>
      <td id="T_5a521_row1_col2" class="data row1 col2" >87</td>
      <td id="T_5a521_row1_col3" class="data row1 col3" >282</td>
    </tr>
    <tr>
      <th id="T_5a521_level0_row2" class="row_heading level0 row2" >3</th>
      <td id="T_5a521_row2_col0" class="data row2 col0" >27</td>
      <td id="T_5a521_row2_col1" class="data row2 col1" >379</td>
      <td id="T_5a521_row2_col2" class="data row2 col2" >166</td>
      <td id="T_5a521_row2_col3" class="data row2 col3" >572</td>
    </tr>
    <tr>
      <th id="T_5a521_level0_row3" class="row_heading level0 row3" >4</th>
      <td id="T_5a521_row3_col0" class="data row3 col0" >15</td>
      <td id="T_5a521_row3_col1" class="data row3 col1" >255</td>
      <td id="T_5a521_row3_col2" class="data row3 col2" >128</td>
      <td id="T_5a521_row3_col3" class="data row3 col3" >398</td>
    </tr>
    <tr>
      <th id="T_5a521_level0_row4" class="row_heading level0 row4" >5</th>
      <td id="T_5a521_row4_col0" class="data row4 col0" >3</td>
      <td id="T_5a521_row4_col1" class="data row4 col1" >30</td>
      <td id="T_5a521_row4_col2" class="data row4 col2" >15</td>
      <td id="T_5a521_row4_col3" class="data row4 col3" >48</td>
    </tr>
    <tr>
      <th id="T_5a521_level0_row5" class="row_heading level0 row5" >All</th>
      <td id="T_5a521_row5_col0" class="data row5 col0" >63</td>
      <td id="T_5a521_row5_col1" class="data row5 col1" >961</td>
      <td id="T_5a521_row5_col2" class="data row5 col2" >446</td>
      <td id="T_5a521_row5_col3" class="data row5 col3" >1470</td>
    </tr>
  </tbody>
</table>




### Comment :
- 65.37% of Employees belong to Research & Development Department. Out of Total 961 Employee no of employee educated at Bachelors,Masters, Doctor are 379,255 and 30 respectively.
- Only 63 Employee work in HR department.


```python
pd.crosstab([df.Education],[df.Department,df.Attrition], margins=True).style.background_gradient(cmap='summer_r')

```




<style type="text/css">
#T_954c9_row0_col0 {
  background-color: #f5fa66;
  color: #000000;
}
#T_954c9_row0_col1, #T_954c9_row4_col0, #T_954c9_row4_col1, #T_954c9_row4_col2, #T_954c9_row4_col3, #T_954c9_row4_col4, #T_954c9_row4_col5, #T_954c9_row4_col6 {
  background-color: #ffff66;
  color: #000000;
}
#T_954c9_row0_col2 {
  background-color: #e9f466;
  color: #000000;
}
#T_954c9_row0_col3 {
  background-color: #e0f066;
  color: #000000;
}
#T_954c9_row0_col4 {
  background-color: #edf666;
  color: #000000;
}
#T_954c9_row0_col5 {
  background-color: #e3f166;
  color: #000000;
}
#T_954c9_row0_col6 {
  background-color: #eaf466;
  color: #000000;
}
#T_954c9_row1_col0, #T_954c9_row1_col4 {
  background-color: #d6eb66;
  color: #000000;
}
#T_954c9_row1_col1, #T_954c9_row3_col1 {
  background-color: #d1e866;
  color: #000000;
}
#T_954c9_row1_col2, #T_954c9_row1_col6 {
  background-color: #d5ea66;
  color: #000000;
}
#T_954c9_row1_col3 {
  background-color: #d8ec66;
  color: #000000;
}
#T_954c9_row1_col5 {
  background-color: #d0e866;
  color: #000000;
}
#T_954c9_row2_col0 {
  background-color: #92c866;
  color: #000000;
}
#T_954c9_row2_col1 {
  background-color: #badc66;
  color: #000000;
}
#T_954c9_row2_col2, #T_954c9_row2_col6 {
  background-color: #a1d066;
  color: #000000;
}
#T_954c9_row2_col3 {
  background-color: #97cb66;
  color: #000000;
}
#T_954c9_row2_col4 {
  background-color: #aad466;
  color: #000000;
}
#T_954c9_row2_col5 {
  background-color: #95ca66;
  color: #000000;
}
#T_954c9_row3_col0 {
  background-color: #cbe566;
  color: #000000;
}
#T_954c9_row3_col2 {
  background-color: #c1e066;
  color: #000000;
}
#T_954c9_row3_col3 {
  background-color: #c6e266;
  color: #000000;
}
#T_954c9_row3_col4 {
  background-color: #bbdd66;
  color: #000000;
}
#T_954c9_row3_col5 {
  background-color: #c2e066;
  color: #000000;
}
#T_954c9_row3_col6 {
  background-color: #c0e066;
  color: #000000;
}
#T_954c9_row5_col0, #T_954c9_row5_col1, #T_954c9_row5_col2, #T_954c9_row5_col3, #T_954c9_row5_col4, #T_954c9_row5_col5, #T_954c9_row5_col6 {
  background-color: #008066;
  color: #f1f1f1;
}
</style>
<table id="T_954c9">
  <thead>
    <tr>
      <th class="index_name level0" >Department</th>
      <th id="T_954c9_level0_col0" class="col_heading level0 col0" colspan="2">Human Resources</th>
      <th id="T_954c9_level0_col2" class="col_heading level0 col2" colspan="2">Research & Development</th>
      <th id="T_954c9_level0_col4" class="col_heading level0 col4" colspan="2">Sales</th>
      <th id="T_954c9_level0_col6" class="col_heading level0 col6" >All</th>
    </tr>
    <tr>
      <th class="index_name level1" >Attrition</th>
      <th id="T_954c9_level1_col0" class="col_heading level1 col0" >No</th>
      <th id="T_954c9_level1_col1" class="col_heading level1 col1" >Yes</th>
      <th id="T_954c9_level1_col2" class="col_heading level1 col2" >No</th>
      <th id="T_954c9_level1_col3" class="col_heading level1 col3" >Yes</th>
      <th id="T_954c9_level1_col4" class="col_heading level1 col4" >No</th>
      <th id="T_954c9_level1_col5" class="col_heading level1 col5" >Yes</th>
      <th id="T_954c9_level1_col6" class="col_heading level1 col6" ></th>
    </tr>
    <tr>
      <th class="index_name level0" >Education</th>
      <th class="blank col0" >&nbsp;</th>
      <th class="blank col1" >&nbsp;</th>
      <th class="blank col2" >&nbsp;</th>
      <th class="blank col3" >&nbsp;</th>
      <th class="blank col4" >&nbsp;</th>
      <th class="blank col5" >&nbsp;</th>
      <th class="blank col6" >&nbsp;</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th id="T_954c9_level0_row0" class="row_heading level0 row0" >1</th>
      <td id="T_954c9_row0_col0" class="data row0 col0" >4</td>
      <td id="T_954c9_row0_col1" class="data row0 col1" >1</td>
      <td id="T_954c9_row0_col2" class="data row0 col2" >96</td>
      <td id="T_954c9_row0_col3" class="data row0 col3" >19</td>
      <td id="T_954c9_row0_col4" class="data row0 col4" >39</td>
      <td id="T_954c9_row0_col5" class="data row0 col5" >11</td>
      <td id="T_954c9_row0_col6" class="data row0 col6" >170</td>
    </tr>
    <tr>
      <th id="T_954c9_level0_row1" class="row_heading level0 row1" >2</th>
      <td id="T_954c9_row1_col0" class="data row1 col0" >10</td>
      <td id="T_954c9_row1_col1" class="data row1 col1" >3</td>
      <td id="T_954c9_row1_col2" class="data row1 col2" >159</td>
      <td id="T_954c9_row1_col3" class="data row1 col3" >23</td>
      <td id="T_954c9_row1_col4" class="data row1 col4" >69</td>
      <td id="T_954c9_row1_col5" class="data row1 col5" >18</td>
      <td id="T_954c9_row1_col6" class="data row1 col6" >282</td>
    </tr>
    <tr>
      <th id="T_954c9_level0_row2" class="row_heading level0 row2" >3</th>
      <td id="T_954c9_row2_col0" class="data row2 col0" >23</td>
      <td id="T_954c9_row2_col1" class="data row2 col1" >4</td>
      <td id="T_954c9_row2_col2" class="data row2 col2" >323</td>
      <td id="T_954c9_row2_col3" class="data row2 col3" >56</td>
      <td id="T_954c9_row2_col4" class="data row2 col4" >127</td>
      <td id="T_954c9_row2_col5" class="data row2 col5" >39</td>
      <td id="T_954c9_row2_col6" class="data row2 col6" >572</td>
    </tr>
    <tr>
      <th id="T_954c9_level0_row3" class="row_heading level0 row3" >4</th>
      <td id="T_954c9_row3_col0" class="data row3 col0" >12</td>
      <td id="T_954c9_row3_col1" class="data row3 col1" >3</td>
      <td id="T_954c9_row3_col2" class="data row3 col2" >223</td>
      <td id="T_954c9_row3_col3" class="data row3 col3" >32</td>
      <td id="T_954c9_row3_col4" class="data row3 col4" >105</td>
      <td id="T_954c9_row3_col5" class="data row3 col5" >23</td>
      <td id="T_954c9_row3_col6" class="data row3 col6" >398</td>
    </tr>
    <tr>
      <th id="T_954c9_level0_row4" class="row_heading level0 row4" >5</th>
      <td id="T_954c9_row4_col0" class="data row4 col0" >2</td>
      <td id="T_954c9_row4_col1" class="data row4 col1" >1</td>
      <td id="T_954c9_row4_col2" class="data row4 col2" >27</td>
      <td id="T_954c9_row4_col3" class="data row4 col3" >3</td>
      <td id="T_954c9_row4_col4" class="data row4 col4" >14</td>
      <td id="T_954c9_row4_col5" class="data row4 col5" >1</td>
      <td id="T_954c9_row4_col6" class="data row4 col6" >48</td>
    </tr>
    <tr>
      <th id="T_954c9_level0_row5" class="row_heading level0 row5" >All</th>
      <td id="T_954c9_row5_col0" class="data row5 col0" >51</td>
      <td id="T_954c9_row5_col1" class="data row5 col1" >12</td>
      <td id="T_954c9_row5_col2" class="data row5 col2" >828</td>
      <td id="T_954c9_row5_col3" class="data row5 col3" >133</td>
      <td id="T_954c9_row5_col4" class="data row5 col4" >354</td>
      <td id="T_954c9_row5_col5" class="data row5 col5" >92</td>
      <td id="T_954c9_row5_col6" class="data row5 col6" >1470</td>
    </tr>
  </tbody>
</table>




### Employee distribution as per education field and level of education


```python
df['EducationField'].value_counts()

```




    Life Sciences       606
    Medical             464
    Marketing           159
    Technical Degree    132
    Other                82
    Human Resources      27
    Name: EducationField, dtype: int64




```python
labels ='Life Sciences','Medical','Marketing','Technical Degree','Other','Human Resources'
fig,ax= plt.subplots()
ax.pie(df['EducationField'].value_counts(),labels=labels, radius=2,autopct= '%3.2f%%',explode=[0.1,0.1,0.125,0.15,0.15,0.175],shadow=True)
plt.show()
```


    
![png](output_33_0.png)
    



```python
# Let check distribution of education Vs education Field
pd.crosstab([df.Education],[df.EducationField], margins=True).style.background_gradient(cmap='summer_r')
```




<style type="text/css">
#T_5d3ea_row0_col0, #T_5d3ea_row1_col0, #T_5d3ea_row4_col0, #T_5d3ea_row4_col1, #T_5d3ea_row4_col2, #T_5d3ea_row4_col3, #T_5d3ea_row4_col4, #T_5d3ea_row4_col5, #T_5d3ea_row4_col6 {
  background-color: #ffff66;
  color: #000000;
}
#T_5d3ea_row0_col1, #T_5d3ea_row0_col6 {
  background-color: #eaf466;
  color: #000000;
}
#T_5d3ea_row0_col2 {
  background-color: #f9fc66;
  color: #000000;
}
#T_5d3ea_row0_col3 {
  background-color: #e4f266;
  color: #000000;
}
#T_5d3ea_row0_col4 {
  background-color: #f3f966;
  color: #000000;
}
#T_5d3ea_row0_col5 {
  background-color: #e0f066;
  color: #000000;
}
#T_5d3ea_row1_col1 {
  background-color: #d4ea66;
  color: #000000;
}
#T_5d3ea_row1_col2 {
  background-color: #e7f366;
  color: #000000;
}
#T_5d3ea_row1_col3 {
  background-color: #d0e866;
  color: #000000;
}
#T_5d3ea_row1_col4 {
  background-color: #c7e366;
  color: #000000;
}
#T_5d3ea_row1_col5 {
  background-color: #daec66;
  color: #000000;
}
#T_5d3ea_row1_col6 {
  background-color: #d5ea66;
  color: #000000;
}
#T_5d3ea_row2_col0 {
  background-color: #70b866;
  color: #f1f1f1;
}
#T_5d3ea_row2_col1 {
  background-color: #a2d066;
  color: #000000;
}
#T_5d3ea_row2_col2 {
  background-color: #abd566;
  color: #000000;
}
#T_5d3ea_row2_col3 {
  background-color: #a0d066;
  color: #000000;
}
#T_5d3ea_row2_col4, #T_5d3ea_row3_col2 {
  background-color: #b7db66;
  color: #000000;
}
#T_5d3ea_row2_col5 {
  background-color: #94ca66;
  color: #000000;
}
#T_5d3ea_row2_col6 {
  background-color: #a1d066;
  color: #000000;
}
#T_5d3ea_row3_col0 {
  background-color: #e1f066;
  color: #000000;
}
#T_5d3ea_row3_col1 {
  background-color: #bcde66;
  color: #000000;
}
#T_5d3ea_row3_col3 {
  background-color: #cde666;
  color: #000000;
}
#T_5d3ea_row3_col4 {
  background-color: #9acc66;
  color: #000000;
}
#T_5d3ea_row3_col5 {
  background-color: #c8e366;
  color: #000000;
}
#T_5d3ea_row3_col6 {
  background-color: #c0e066;
  color: #000000;
}
#T_5d3ea_row5_col0, #T_5d3ea_row5_col1, #T_5d3ea_row5_col2, #T_5d3ea_row5_col3, #T_5d3ea_row5_col4, #T_5d3ea_row5_col5, #T_5d3ea_row5_col6 {
  background-color: #008066;
  color: #f1f1f1;
}
</style>
<table id="T_5d3ea">
  <thead>
    <tr>
      <th class="index_name level0" >EducationField</th>
      <th id="T_5d3ea_level0_col0" class="col_heading level0 col0" >Human Resources</th>
      <th id="T_5d3ea_level0_col1" class="col_heading level0 col1" >Life Sciences</th>
      <th id="T_5d3ea_level0_col2" class="col_heading level0 col2" >Marketing</th>
      <th id="T_5d3ea_level0_col3" class="col_heading level0 col3" >Medical</th>
      <th id="T_5d3ea_level0_col4" class="col_heading level0 col4" >Other</th>
      <th id="T_5d3ea_level0_col5" class="col_heading level0 col5" >Technical Degree</th>
      <th id="T_5d3ea_level0_col6" class="col_heading level0 col6" >All</th>
    </tr>
    <tr>
      <th class="index_name level0" >Education</th>
      <th class="blank col0" >&nbsp;</th>
      <th class="blank col1" >&nbsp;</th>
      <th class="blank col2" >&nbsp;</th>
      <th class="blank col3" >&nbsp;</th>
      <th class="blank col4" >&nbsp;</th>
      <th class="blank col5" >&nbsp;</th>
      <th class="blank col6" >&nbsp;</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th id="T_5d3ea_level0_row0" class="row_heading level0 row0" >1</th>
      <td id="T_5d3ea_row0_col0" class="data row0 col0" >2</td>
      <td id="T_5d3ea_row0_col1" class="data row0 col1" >67</td>
      <td id="T_5d3ea_row0_col2" class="data row0 col2" >14</td>
      <td id="T_5d3ea_row0_col3" class="data row0 col3" >63</td>
      <td id="T_5d3ea_row0_col4" class="data row0 col4" >5</td>
      <td id="T_5d3ea_row0_col5" class="data row0 col5" >19</td>
      <td id="T_5d3ea_row0_col6" class="data row0 col6" >170</td>
    </tr>
    <tr>
      <th id="T_5d3ea_level0_row1" class="row_heading level0 row1" >2</th>
      <td id="T_5d3ea_row1_col0" class="data row1 col0" >2</td>
      <td id="T_5d3ea_row1_col1" class="data row1 col1" >116</td>
      <td id="T_5d3ea_row1_col2" class="data row1 col2" >24</td>
      <td id="T_5d3ea_row1_col3" class="data row1 col3" >99</td>
      <td id="T_5d3ea_row1_col4" class="data row1 col4" >19</td>
      <td id="T_5d3ea_row1_col5" class="data row1 col5" >22</td>
      <td id="T_5d3ea_row1_col6" class="data row1 col6" >282</td>
    </tr>
    <tr>
      <th id="T_5d3ea_level0_row2" class="row_heading level0 row2" >3</th>
      <td id="T_5d3ea_row2_col0" class="data row2 col0" >16</td>
      <td id="T_5d3ea_row2_col1" class="data row2 col1" >233</td>
      <td id="T_5d3ea_row2_col2" class="data row2 col2" >59</td>
      <td id="T_5d3ea_row2_col3" class="data row2 col3" >183</td>
      <td id="T_5d3ea_row2_col4" class="data row2 col4" >24</td>
      <td id="T_5d3ea_row2_col5" class="data row2 col5" >57</td>
      <td id="T_5d3ea_row2_col6" class="data row2 col6" >572</td>
    </tr>
    <tr>
      <th id="T_5d3ea_level0_row3" class="row_heading level0 row3" >4</th>
      <td id="T_5d3ea_row3_col0" class="data row3 col0" >5</td>
      <td id="T_5d3ea_row3_col1" class="data row3 col1" >173</td>
      <td id="T_5d3ea_row3_col2" class="data row3 col2" >52</td>
      <td id="T_5d3ea_row3_col3" class="data row3 col3" >104</td>
      <td id="T_5d3ea_row3_col4" class="data row3 col4" >33</td>
      <td id="T_5d3ea_row3_col5" class="data row3 col5" >31</td>
      <td id="T_5d3ea_row3_col6" class="data row3 col6" >398</td>
    </tr>
    <tr>
      <th id="T_5d3ea_level0_row4" class="row_heading level0 row4" >5</th>
      <td id="T_5d3ea_row4_col0" class="data row4 col0" >2</td>
      <td id="T_5d3ea_row4_col1" class="data row4 col1" >17</td>
      <td id="T_5d3ea_row4_col2" class="data row4 col2" >10</td>
      <td id="T_5d3ea_row4_col3" class="data row4 col3" >15</td>
      <td id="T_5d3ea_row4_col4" class="data row4 col4" >1</td>
      <td id="T_5d3ea_row4_col5" class="data row4 col5" >3</td>
      <td id="T_5d3ea_row4_col6" class="data row4 col6" >48</td>
    </tr>
    <tr>
      <th id="T_5d3ea_level0_row5" class="row_heading level0 row5" >All</th>
      <td id="T_5d3ea_row5_col0" class="data row5 col0" >27</td>
      <td id="T_5d3ea_row5_col1" class="data row5 col1" >606</td>
      <td id="T_5d3ea_row5_col2" class="data row5 col2" >159</td>
      <td id="T_5d3ea_row5_col3" class="data row5 col3" >464</td>
      <td id="T_5d3ea_row5_col4" class="data row5 col4" >82</td>
      <td id="T_5d3ea_row5_col5" class="data row5 col5" >132</td>
      <td id="T_5d3ea_row5_col6" class="data row5 col6" >1470</td>
    </tr>
  </tbody>
</table>





```python
# Let check distribution of department Vs education Field

pd.crosstab([df.Department],[df.EducationField], margins=True).style.background_gradient(cmap='summer_r')

```




<style type="text/css">
#T_428cf_row0_col0, #T_428cf_row2_col2, #T_428cf_row3_col0, #T_428cf_row3_col1, #T_428cf_row3_col2, #T_428cf_row3_col3, #T_428cf_row3_col4, #T_428cf_row3_col5, #T_428cf_row3_col6 {
  background-color: #008066;
  color: #f1f1f1;
}
#T_428cf_row0_col1, #T_428cf_row0_col2, #T_428cf_row0_col3, #T_428cf_row0_col4, #T_428cf_row0_col5, #T_428cf_row0_col6, #T_428cf_row1_col0, #T_428cf_row1_col2, #T_428cf_row2_col0 {
  background-color: #ffff66;
  color: #000000;
}
#T_428cf_row1_col1 {
  background-color: #48a366;
  color: #f1f1f1;
}
#T_428cf_row1_col3 {
  background-color: #399c66;
  color: #f1f1f1;
}
#T_428cf_row1_col4 {
  background-color: #3a9c66;
  color: #f1f1f1;
}
#T_428cf_row1_col5 {
  background-color: #4ba566;
  color: #f1f1f1;
}
#T_428cf_row1_col6 {
  background-color: #5cae66;
  color: #f1f1f1;
}
#T_428cf_row2_col1 {
  background-color: #c5e266;
  color: #000000;
}
#T_428cf_row2_col3 {
  background-color: #d5ea66;
  color: #000000;
}
#T_428cf_row2_col4 {
  background-color: #d9ec66;
  color: #000000;
}
#T_428cf_row2_col5 {
  background-color: #c3e166;
  color: #000000;
}
#T_428cf_row2_col6 {
  background-color: #badc66;
  color: #000000;
}
</style>
<table id="T_428cf">
  <thead>
    <tr>
      <th class="index_name level0" >EducationField</th>
      <th id="T_428cf_level0_col0" class="col_heading level0 col0" >Human Resources</th>
      <th id="T_428cf_level0_col1" class="col_heading level0 col1" >Life Sciences</th>
      <th id="T_428cf_level0_col2" class="col_heading level0 col2" >Marketing</th>
      <th id="T_428cf_level0_col3" class="col_heading level0 col3" >Medical</th>
      <th id="T_428cf_level0_col4" class="col_heading level0 col4" >Other</th>
      <th id="T_428cf_level0_col5" class="col_heading level0 col5" >Technical Degree</th>
      <th id="T_428cf_level0_col6" class="col_heading level0 col6" >All</th>
    </tr>
    <tr>
      <th class="index_name level0" >Department</th>
      <th class="blank col0" >&nbsp;</th>
      <th class="blank col1" >&nbsp;</th>
      <th class="blank col2" >&nbsp;</th>
      <th class="blank col3" >&nbsp;</th>
      <th class="blank col4" >&nbsp;</th>
      <th class="blank col5" >&nbsp;</th>
      <th class="blank col6" >&nbsp;</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th id="T_428cf_level0_row0" class="row_heading level0 row0" >Human Resources</th>
      <td id="T_428cf_row0_col0" class="data row0 col0" >27</td>
      <td id="T_428cf_row0_col1" class="data row0 col1" >16</td>
      <td id="T_428cf_row0_col2" class="data row0 col2" >0</td>
      <td id="T_428cf_row0_col3" class="data row0 col3" >13</td>
      <td id="T_428cf_row0_col4" class="data row0 col4" >3</td>
      <td id="T_428cf_row0_col5" class="data row0 col5" >4</td>
      <td id="T_428cf_row0_col6" class="data row0 col6" >63</td>
    </tr>
    <tr>
      <th id="T_428cf_level0_row1" class="row_heading level0 row1" >Research & Development</th>
      <td id="T_428cf_row1_col0" class="data row1 col0" >0</td>
      <td id="T_428cf_row1_col1" class="data row1 col1" >440</td>
      <td id="T_428cf_row1_col2" class="data row1 col2" >0</td>
      <td id="T_428cf_row1_col3" class="data row1 col3" >363</td>
      <td id="T_428cf_row1_col4" class="data row1 col4" >64</td>
      <td id="T_428cf_row1_col5" class="data row1 col5" >94</td>
      <td id="T_428cf_row1_col6" class="data row1 col6" >961</td>
    </tr>
    <tr>
      <th id="T_428cf_level0_row2" class="row_heading level0 row2" >Sales</th>
      <td id="T_428cf_row2_col0" class="data row2 col0" >0</td>
      <td id="T_428cf_row2_col1" class="data row2 col1" >150</td>
      <td id="T_428cf_row2_col2" class="data row2 col2" >159</td>
      <td id="T_428cf_row2_col3" class="data row2 col3" >88</td>
      <td id="T_428cf_row2_col4" class="data row2 col4" >15</td>
      <td id="T_428cf_row2_col5" class="data row2 col5" >34</td>
      <td id="T_428cf_row2_col6" class="data row2 col6" >446</td>
    </tr>
    <tr>
      <th id="T_428cf_level0_row3" class="row_heading level0 row3" >All</th>
      <td id="T_428cf_row3_col0" class="data row3 col0" >27</td>
      <td id="T_428cf_row3_col1" class="data row3 col1" >606</td>
      <td id="T_428cf_row3_col2" class="data row3 col2" >159</td>
      <td id="T_428cf_row3_col3" class="data row3 col3" >464</td>
      <td id="T_428cf_row3_col4" class="data row3 col4" >82</td>
      <td id="T_428cf_row3_col5" class="data row3 col5" >132</td>
      <td id="T_428cf_row3_col6" class="data row3 col6" >1470</td>
    </tr>
  </tbody>
</table>




### Comment:
- 41.22 % Employee comes from Life science background followed by Medical profession with 31.56%.
- There are only 27 people with HR background and We know that 63 people work in HR Department from previous result. This implies that atleast half employee working in HR department do not have HR background. This important as there is more probability of Employees Retention is when they are working in domain of interest or as per their education background. Dissatisfaction with want we doing can be seen as major reason of leaving job.
- Most of Employees with Techanical degree are Bachelors.
- Most of Employees having Masters and Doctors belong to Life Science and Medical domain.
- R&D department almost everyone comes from profession or technical background except support staff. Factor like Salary Hike, travelling, overtime and Job level are things need to taken in consideration while analysing Attrition of this category.
- There are 159 Employee with Marketing background and all work in Sales Department.
- 50% Employees in sales department have background of Life sciences & Medical. So it will interesting to see attrition rate in these employees.
- We will Analysis Attrition over above insight in next section of Job role.



### Lets work with Job Role


```python
plt.figure(figsize=(15,7))
sns.countplot(df['JobRole'])
plt.xticks(rotation=45)
plt.show()
```


    
![png](output_37_0.png)
    


- Before going for Attrition by Job role


first build matrix of department vs job role which will give us idea about number of employees of different job role across department


```python
pd.crosstab([df.JobRole],[df.Department], margins=True).style.background_gradient(cmap='gist_rainbow_r')

```




<style type="text/css">
#T_95a00_row0_col0, #T_95a00_row0_col2, #T_95a00_row1_col1, #T_95a00_row1_col2, #T_95a00_row1_col3, #T_95a00_row2_col0, #T_95a00_row2_col2, #T_95a00_row4_col0, #T_95a00_row4_col2, #T_95a00_row5_col0, #T_95a00_row5_col2, #T_95a00_row6_col0, #T_95a00_row6_col2, #T_95a00_row7_col0, #T_95a00_row7_col1, #T_95a00_row8_col0, #T_95a00_row8_col1 {
  background-color: #ff00bf;
  color: #f1f1f1;
}
#T_95a00_row0_col1 {
  background-color: #8600ff;
  color: #f1f1f1;
}
#T_95a00_row0_col3, #T_95a00_row3_col1 {
  background-color: #f300ff;
  color: #f1f1f1;
}
#T_95a00_row1_col0 {
  background-color: #ffc400;
  color: #000000;
}
#T_95a00_row2_col1 {
  background-color: #0033ff;
  color: #f1f1f1;
}
#T_95a00_row2_col3 {
  background-color: #7600ff;
  color: #f1f1f1;
}
#T_95a00_row3_col0 {
  background-color: #5000ff;
  color: #f1f1f1;
}
#T_95a00_row3_col2, #T_95a00_row5_col1 {
  background-color: #cd00ff;
  color: #f1f1f1;
}
#T_95a00_row3_col3 {
  background-color: #ff00f0;
  color: #f1f1f1;
}
#T_95a00_row4_col1 {
  background-color: #7000ff;
  color: #f1f1f1;
}
#T_95a00_row4_col3 {
  background-color: #e800ff;
  color: #f1f1f1;
}
#T_95a00_row5_col3, #T_95a00_row8_col3 {
  background-color: #ff00da;
  color: #f1f1f1;
}
#T_95a00_row6_col1 {
  background-color: #0064ff;
  color: #f1f1f1;
}
#T_95a00_row6_col3 {
  background-color: #5500ff;
  color: #f1f1f1;
}
#T_95a00_row7_col2 {
  background-color: #b8ff00;
  color: #000000;
}
#T_95a00_row7_col3 {
  background-color: #3400ff;
  color: #f1f1f1;
}
#T_95a00_row8_col2 {
  background-color: #3f00ff;
  color: #f1f1f1;
}
#T_95a00_row9_col0, #T_95a00_row9_col1, #T_95a00_row9_col2, #T_95a00_row9_col3 {
  background-color: #ff0029;
  color: #f1f1f1;
}
</style>
<table id="T_95a00">
  <thead>
    <tr>
      <th class="index_name level0" >Department</th>
      <th id="T_95a00_level0_col0" class="col_heading level0 col0" >Human Resources</th>
      <th id="T_95a00_level0_col1" class="col_heading level0 col1" >Research & Development</th>
      <th id="T_95a00_level0_col2" class="col_heading level0 col2" >Sales</th>
      <th id="T_95a00_level0_col3" class="col_heading level0 col3" >All</th>
    </tr>
    <tr>
      <th class="index_name level0" >JobRole</th>
      <th class="blank col0" >&nbsp;</th>
      <th class="blank col1" >&nbsp;</th>
      <th class="blank col2" >&nbsp;</th>
      <th class="blank col3" >&nbsp;</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th id="T_95a00_level0_row0" class="row_heading level0 row0" >Healthcare Representative</th>
      <td id="T_95a00_row0_col0" class="data row0 col0" >0</td>
      <td id="T_95a00_row0_col1" class="data row0 col1" >131</td>
      <td id="T_95a00_row0_col2" class="data row0 col2" >0</td>
      <td id="T_95a00_row0_col3" class="data row0 col3" >131</td>
    </tr>
    <tr>
      <th id="T_95a00_level0_row1" class="row_heading level0 row1" >Human Resources</th>
      <td id="T_95a00_row1_col0" class="data row1 col0" >52</td>
      <td id="T_95a00_row1_col1" class="data row1 col1" >0</td>
      <td id="T_95a00_row1_col2" class="data row1 col2" >0</td>
      <td id="T_95a00_row1_col3" class="data row1 col3" >52</td>
    </tr>
    <tr>
      <th id="T_95a00_level0_row2" class="row_heading level0 row2" >Laboratory Technician</th>
      <td id="T_95a00_row2_col0" class="data row2 col0" >0</td>
      <td id="T_95a00_row2_col1" class="data row2 col1" >259</td>
      <td id="T_95a00_row2_col2" class="data row2 col2" >0</td>
      <td id="T_95a00_row2_col3" class="data row2 col3" >259</td>
    </tr>
    <tr>
      <th id="T_95a00_level0_row3" class="row_heading level0 row3" >Manager</th>
      <td id="T_95a00_row3_col0" class="data row3 col0" >11</td>
      <td id="T_95a00_row3_col1" class="data row3 col1" >54</td>
      <td id="T_95a00_row3_col2" class="data row3 col2" >37</td>
      <td id="T_95a00_row3_col3" class="data row3 col3" >102</td>
    </tr>
    <tr>
      <th id="T_95a00_level0_row4" class="row_heading level0 row4" >Manufacturing Director</th>
      <td id="T_95a00_row4_col0" class="data row4 col0" >0</td>
      <td id="T_95a00_row4_col1" class="data row4 col1" >145</td>
      <td id="T_95a00_row4_col2" class="data row4 col2" >0</td>
      <td id="T_95a00_row4_col3" class="data row4 col3" >145</td>
    </tr>
    <tr>
      <th id="T_95a00_level0_row5" class="row_heading level0 row5" >Research Director</th>
      <td id="T_95a00_row5_col0" class="data row5 col0" >0</td>
      <td id="T_95a00_row5_col1" class="data row5 col1" >80</td>
      <td id="T_95a00_row5_col2" class="data row5 col2" >0</td>
      <td id="T_95a00_row5_col3" class="data row5 col3" >80</td>
    </tr>
    <tr>
      <th id="T_95a00_level0_row6" class="row_heading level0 row6" >Research Scientist</th>
      <td id="T_95a00_row6_col0" class="data row6 col0" >0</td>
      <td id="T_95a00_row6_col1" class="data row6 col1" >292</td>
      <td id="T_95a00_row6_col2" class="data row6 col2" >0</td>
      <td id="T_95a00_row6_col3" class="data row6 col3" >292</td>
    </tr>
    <tr>
      <th id="T_95a00_level0_row7" class="row_heading level0 row7" >Sales Executive</th>
      <td id="T_95a00_row7_col0" class="data row7 col0" >0</td>
      <td id="T_95a00_row7_col1" class="data row7 col1" >0</td>
      <td id="T_95a00_row7_col2" class="data row7 col2" >326</td>
      <td id="T_95a00_row7_col3" class="data row7 col3" >326</td>
    </tr>
    <tr>
      <th id="T_95a00_level0_row8" class="row_heading level0 row8" >Sales Representative</th>
      <td id="T_95a00_row8_col0" class="data row8 col0" >0</td>
      <td id="T_95a00_row8_col1" class="data row8 col1" >0</td>
      <td id="T_95a00_row8_col2" class="data row8 col2" >83</td>
      <td id="T_95a00_row8_col3" class="data row8 col3" >83</td>
    </tr>
    <tr>
      <th id="T_95a00_level0_row9" class="row_heading level0 row9" >All</th>
      <td id="T_95a00_row9_col0" class="data row9 col0" >63</td>
      <td id="T_95a00_row9_col1" class="data row9 col1" >961</td>
      <td id="T_95a00_row9_col2" class="data row9 col2" >446</td>
      <td id="T_95a00_row9_col3" class="data row9 col3" >1470</td>
    </tr>
  </tbody>
</table>




### Comment:
- There are 3 job role in HR Department, maximum of which are sales Executive with 446 Total Employees.
- Human Resources department has 2 Job role i.e. HR & Manager.
- There 6 different Job role in R&D department with total 961 employees and until now we know that all of them belong to thier respective domain background.


```python
plt.figure(figsize=(12,10))
data=pd.crosstab(df['JobRole'], df['Attrition'])
data.div(data.sum(1).astype(float), axis=0).plot(kind='bar', stacked=True, 
                    color=['green', 'red'],figsize=(12,8))
plt.title('Attrition as per Job Role', fontsize=20)
plt.xlabel('Job Role',fontsize=15)
plt.show()
```


    <Figure size 1200x1000 with 0 Axes>



    
![png](output_41_1.png)
    


- We all can definitely see Red Signal for different Managers & HR of Respective Job Role in above barplot !!!


```python
pd.crosstab([df.JobRole,df.Department],[df.Attrition], margins=True).style.background_gradient(cmap='gist_rainbow_r')

```




<style type="text/css">
#T_0ef35_row0_col0, #T_0ef35_row6_col2 {
  background-color: #c200ff;
  color: #f1f1f1;
}
#T_0ef35_row0_col1 {
  background-color: #ff00f0;
  color: #f1f1f1;
}
#T_0ef35_row0_col2 {
  background-color: #cd00ff;
  color: #f1f1f1;
}
#T_0ef35_row1_col0 {
  background-color: #ff00e0;
  color: #f1f1f1;
}
#T_0ef35_row1_col1, #T_0ef35_row7_col2, #T_0ef35_row10_col2 {
  background-color: #fe00ff;
  color: #f1f1f1;
}
#T_0ef35_row1_col2, #T_0ef35_row4_col2 {
  background-color: #ff00e5;
  color: #f1f1f1;
}
#T_0ef35_row2_col0 {
  background-color: #7000ff;
  color: #f1f1f1;
}
#T_0ef35_row2_col1 {
  background-color: #0028ff;
  color: #f1f1f1;
}
#T_0ef35_row2_col2 {
  background-color: #5500ff;
  color: #f1f1f1;
}
#T_0ef35_row3_col0, #T_0ef35_row3_col1, #T_0ef35_row3_col2 {
  background-color: #ff00bf;
  color: #f1f1f1;
}
#T_0ef35_row4_col0, #T_0ef35_row10_col0 {
  background-color: #ff00eb;
  color: #f1f1f1;
}
#T_0ef35_row4_col1 {
  background-color: #ff00d0;
  color: #f1f1f1;
}
#T_0ef35_row5_col0 {
  background-color: #ff00da;
  color: #f1f1f1;
}
#T_0ef35_row5_col1, #T_0ef35_row7_col1 {
  background-color: #ff00ca;
  color: #f1f1f1;
}
#T_0ef35_row5_col2 {
  background-color: #ff00d5;
  color: #f1f1f1;
}
#T_0ef35_row6_col0 {
  background-color: #b700ff;
  color: #f1f1f1;
}
#T_0ef35_row6_col1 {
  background-color: #ff00f6;
  color: #f1f1f1;
}
#T_0ef35_row7_col0 {
  background-color: #f300ff;
  color: #f1f1f1;
}
#T_0ef35_row8_col0, #T_0ef35_row8_col2 {
  background-color: #3400ff;
  color: #f1f1f1;
}
#T_0ef35_row8_col1 {
  background-color: #2f00ff;
  color: #f1f1f1;
}
#T_0ef35_row9_col0 {
  background-color: #1900ff;
  color: #f1f1f1;
}
#T_0ef35_row9_col1 {
  background-color: #000dff;
  color: #f1f1f1;
}
#T_0ef35_row9_col2 {
  background-color: #1400ff;
  color: #f1f1f1;
}
#T_0ef35_row10_col1 {
  background-color: #8100ff;
  color: #f1f1f1;
}
#T_0ef35_row11_col0, #T_0ef35_row11_col1, #T_0ef35_row11_col2 {
  background-color: #ff0029;
  color: #f1f1f1;
}
</style>
<table id="T_0ef35">
  <thead>
    <tr>
      <th class="blank" >&nbsp;</th>
      <th class="index_name level0" >Attrition</th>
      <th id="T_0ef35_level0_col0" class="col_heading level0 col0" >No</th>
      <th id="T_0ef35_level0_col1" class="col_heading level0 col1" >Yes</th>
      <th id="T_0ef35_level0_col2" class="col_heading level0 col2" >All</th>
    </tr>
    <tr>
      <th class="index_name level0" >JobRole</th>
      <th class="index_name level1" >Department</th>
      <th class="blank col0" >&nbsp;</th>
      <th class="blank col1" >&nbsp;</th>
      <th class="blank col2" >&nbsp;</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th id="T_0ef35_level0_row0" class="row_heading level0 row0" >Healthcare Representative</th>
      <th id="T_0ef35_level1_row0" class="row_heading level1 row0" >Research & Development</th>
      <td id="T_0ef35_row0_col0" class="data row0 col0" >122</td>
      <td id="T_0ef35_row0_col1" class="data row0 col1" >9</td>
      <td id="T_0ef35_row0_col2" class="data row0 col2" >131</td>
    </tr>
    <tr>
      <th id="T_0ef35_level0_row1" class="row_heading level0 row1" >Human Resources</th>
      <th id="T_0ef35_level1_row1" class="row_heading level1 row1" >Human Resources</th>
      <td id="T_0ef35_row1_col0" class="data row1 col0" >40</td>
      <td id="T_0ef35_row1_col1" class="data row1 col1" >12</td>
      <td id="T_0ef35_row1_col2" class="data row1 col2" >52</td>
    </tr>
    <tr>
      <th id="T_0ef35_level0_row2" class="row_heading level0 row2" >Laboratory Technician</th>
      <th id="T_0ef35_level1_row2" class="row_heading level1 row2" >Research & Development</th>
      <td id="T_0ef35_row2_col0" class="data row2 col0" >197</td>
      <td id="T_0ef35_row2_col1" class="data row2 col1" >62</td>
      <td id="T_0ef35_row2_col2" class="data row2 col2" >259</td>
    </tr>
    <tr>
      <th id="T_0ef35_level0_row3" class="row_heading level0 row3" rowspan="3">Manager</th>
      <th id="T_0ef35_level1_row3" class="row_heading level1 row3" >Human Resources</th>
      <td id="T_0ef35_row3_col0" class="data row3 col0" >11</td>
      <td id="T_0ef35_row3_col1" class="data row3 col1" >0</td>
      <td id="T_0ef35_row3_col2" class="data row3 col2" >11</td>
    </tr>
    <tr>
      <th id="T_0ef35_level1_row4" class="row_heading level1 row4" >Research & Development</th>
      <td id="T_0ef35_row4_col0" class="data row4 col0" >51</td>
      <td id="T_0ef35_row4_col1" class="data row4 col1" >3</td>
      <td id="T_0ef35_row4_col2" class="data row4 col2" >54</td>
    </tr>
    <tr>
      <th id="T_0ef35_level1_row5" class="row_heading level1 row5" >Sales</th>
      <td id="T_0ef35_row5_col0" class="data row5 col0" >35</td>
      <td id="T_0ef35_row5_col1" class="data row5 col1" >2</td>
      <td id="T_0ef35_row5_col2" class="data row5 col2" >37</td>
    </tr>
    <tr>
      <th id="T_0ef35_level0_row6" class="row_heading level0 row6" >Manufacturing Director</th>
      <th id="T_0ef35_level1_row6" class="row_heading level1 row6" >Research & Development</th>
      <td id="T_0ef35_row6_col0" class="data row6 col0" >135</td>
      <td id="T_0ef35_row6_col1" class="data row6 col1" >10</td>
      <td id="T_0ef35_row6_col2" class="data row6 col2" >145</td>
    </tr>
    <tr>
      <th id="T_0ef35_level0_row7" class="row_heading level0 row7" >Research Director</th>
      <th id="T_0ef35_level1_row7" class="row_heading level1 row7" >Research & Development</th>
      <td id="T_0ef35_row7_col0" class="data row7 col0" >78</td>
      <td id="T_0ef35_row7_col1" class="data row7 col1" >2</td>
      <td id="T_0ef35_row7_col2" class="data row7 col2" >80</td>
    </tr>
    <tr>
      <th id="T_0ef35_level0_row8" class="row_heading level0 row8" >Research Scientist</th>
      <th id="T_0ef35_level1_row8" class="row_heading level1 row8" >Research & Development</th>
      <td id="T_0ef35_row8_col0" class="data row8 col0" >245</td>
      <td id="T_0ef35_row8_col1" class="data row8 col1" >47</td>
      <td id="T_0ef35_row8_col2" class="data row8 col2" >292</td>
    </tr>
    <tr>
      <th id="T_0ef35_level0_row9" class="row_heading level0 row9" >Sales Executive</th>
      <th id="T_0ef35_level1_row9" class="row_heading level1 row9" >Sales</th>
      <td id="T_0ef35_row9_col0" class="data row9 col0" >269</td>
      <td id="T_0ef35_row9_col1" class="data row9 col1" >57</td>
      <td id="T_0ef35_row9_col2" class="data row9 col2" >326</td>
    </tr>
    <tr>
      <th id="T_0ef35_level0_row10" class="row_heading level0 row10" >Sales Representative</th>
      <th id="T_0ef35_level1_row10" class="row_heading level1 row10" >Sales</th>
      <td id="T_0ef35_row10_col0" class="data row10 col0" >50</td>
      <td id="T_0ef35_row10_col1" class="data row10 col1" >33</td>
      <td id="T_0ef35_row10_col2" class="data row10 col2" >83</td>
    </tr>
    <tr>
      <th id="T_0ef35_level0_row11" class="row_heading level0 row11" >All</th>
      <th id="T_0ef35_level1_row11" class="row_heading level1 row11" ></th>
      <td id="T_0ef35_row11_col0" class="data row11 col0" >1233</td>
      <td id="T_0ef35_row11_col1" class="data row11 col1" >237</td>
      <td id="T_0ef35_row11_col2" class="data row11 col2" >1470</td>
    </tr>
  </tbody>
</table>




### Comment:
- Percentage of attrition is high in Sales Representative,Laboratory Technician,Human Resources. This all job role comes at bottom in corparate hierachy also Salary is comparatively less compare to other job role.
- Monthly Income, Job stastifation, travelling are feature need to dive into for further insights in these job role.
- At the Top chart 62 Laboratory Technician has resign from job, followed by 57 sales executive and 47 Research Scientist.
- 16 % arttrition rate for Research Scientist, which involve huge investment from company. Company not only loses employee but its knowledge base, expertise & Intellatual property rights in some cases.


```python
# Grouping Numeric Features
Numeric=['Age', 'DailyRate', 'DistanceFromHome',  
 'EnvironmentSatisfaction', 'HourlyRate', 'JobInvolvement', 'JobLevel', 'JobSatisfaction', 
 'MonthlyIncome', 'MonthlyRate', 'NumCompaniesWorked', 'PercentSalaryHike', 'PerformanceRating', 
 'RelationshipSatisfaction','StockOptionLevel', 'TotalWorkingYears', 'TrainingTimesLastYear',
 'WorkLifeBalance', 'YearsAtCompany', 'YearsInCurrentRole', 'YearsSinceLastPromotion', 'YearsWithCurrManager']

```

### Violinplot of Numeric Variables


```python
# Grouping Numeric Features
Numeric_int=['Age', 'DailyRate', 'DistanceFromHome', 'HourlyRate','MonthlyIncome', 'MonthlyRate', 
             'NumCompaniesWorked', 'PercentSalaryHike', 'TotalWorkingYears','TrainingTimesLastYear',
             'YearsAtCompany', 'YearsInCurrentRole', 'YearsSinceLastPromotion', 'YearsWithCurrManager']

```


```python
sns.set_palette('spring')
plt.figure(figsize=(20,50), facecolor='white')
plotnumber =1

for i in Numeric_int:
    if plotnumber <=25:
        ax = plt.subplot(9,3,plotnumber)
        sns.violinplot(df[i])
        plt.xlabel(i,fontsize=20)
        plt.xticks(rotation=30)
    plotnumber+=1
plt.tight_layout()
plt.show()

```


    
![png](output_48_0.png)
    


### Comment:
- For Majority of people have spend 3 to 10 years at company.
- Most of people staying company upto 2 years after promotion.
- Majority of people are are train 2-3 times in last year.If employees leaves job then it loss investment for company.
- Majority of people stay in same role for maximum 4 yrs.
- Majority of Employees have salary hike of 10 to 15%.


### Age Vs Attrition


```python
plt.subplots(figsize=(12,6))
sns.countplot(df['Age'])
```




    <AxesSubplot:xlabel='Age', ylabel='count'>




    
![png](output_50_1.png)
    



```python
sns.set_palette('hsv')
plt.subplots(figsize=(18,8))
sns.countplot(x='Age', hue='Attrition', data=df)
```




    <AxesSubplot:xlabel='Age', ylabel='count'>




    
![png](output_51_1.png)
    


### Comment:
- The Attrition rate is minimum between the Age years of 34 and 35.
- The Attrition rate is maximum between the Age years of 29 and 31.


```python
plt.figure(figsize=(15,8))
sns.barplot(df['TotalWorkingYears'],df['MonthlyIncome'])
plt.xlabel('Total Working Years',fontsize=20)
plt.ylabel('Monthly Income',fontsize=20)
plt.title(" Total Working Years vs Monthly Income", fontsize=20)
plt.show()
```


    
![png](output_53_0.png)
    


### Comment:
- Monthly Income is highest for the employees with 21 or more number of Total Working Years.


```python
plt.figure(figsize=(8,6))
sns.barplot(x='Attrition',y='MonthlyIncome',data=df)
plt.xticks(fontsize=18)
plt.yticks(fontsize=18)
plt.show()
```


    
![png](output_55_0.png)
    


### Comment:
- The Attrition rate in the employees is less when the monthly income reaches to 6900.


```python
plt.figure(figsize=(8,6))
sns.barplot(x='Attrition',y='YearsSinceLastPromotion',data=df)
plt.xticks(fontsize=18)
plt.yticks(fontsize=18)
plt.show()
```


    
![png](output_57_0.png)
    


### Comment:
- The rate of Attrition is high when the employee did not got promoted since 1.8 years.

# Encoding categorical data


```python
# Using Label Encoder on target variable
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
df["Attrition"] = le.fit_transform(df["Attrition"])
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Attrition</th>
      <th>BusinessTravel</th>
      <th>DailyRate</th>
      <th>Department</th>
      <th>DistanceFromHome</th>
      <th>Education</th>
      <th>EducationField</th>
      <th>EmployeeCount</th>
      <th>EmployeeNumber</th>
      <th>EnvironmentSatisfaction</th>
      <th>Gender</th>
      <th>HourlyRate</th>
      <th>JobInvolvement</th>
      <th>JobLevel</th>
      <th>JobRole</th>
      <th>JobSatisfaction</th>
      <th>MaritalStatus</th>
      <th>MonthlyIncome</th>
      <th>MonthlyRate</th>
      <th>NumCompaniesWorked</th>
      <th>Over18</th>
      <th>OverTime</th>
      <th>PercentSalaryHike</th>
      <th>PerformanceRating</th>
      <th>RelationshipSatisfaction</th>
      <th>StandardHours</th>
      <th>StockOptionLevel</th>
      <th>TotalWorkingYears</th>
      <th>TrainingTimesLastYear</th>
      <th>WorkLifeBalance</th>
      <th>YearsAtCompany</th>
      <th>YearsInCurrentRole</th>
      <th>YearsSinceLastPromotion</th>
      <th>YearsWithCurrManager</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>41</td>
      <td>1</td>
      <td>Travel_Rarely</td>
      <td>1102</td>
      <td>Sales</td>
      <td>1</td>
      <td>2</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>Female</td>
      <td>94</td>
      <td>3</td>
      <td>2</td>
      <td>Sales Executive</td>
      <td>4</td>
      <td>Single</td>
      <td>5993</td>
      <td>19479</td>
      <td>8</td>
      <td>Y</td>
      <td>Yes</td>
      <td>11</td>
      <td>3</td>
      <td>1</td>
      <td>80</td>
      <td>0</td>
      <td>8</td>
      <td>0</td>
      <td>1</td>
      <td>6</td>
      <td>4</td>
      <td>0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>49</td>
      <td>0</td>
      <td>Travel_Frequently</td>
      <td>279</td>
      <td>Research &amp; Development</td>
      <td>8</td>
      <td>1</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>Male</td>
      <td>61</td>
      <td>2</td>
      <td>2</td>
      <td>Research Scientist</td>
      <td>2</td>
      <td>Married</td>
      <td>5130</td>
      <td>24907</td>
      <td>1</td>
      <td>Y</td>
      <td>No</td>
      <td>23</td>
      <td>4</td>
      <td>4</td>
      <td>80</td>
      <td>1</td>
      <td>10</td>
      <td>3</td>
      <td>3</td>
      <td>10</td>
      <td>7</td>
      <td>1</td>
      <td>7</td>
    </tr>
    <tr>
      <th>2</th>
      <td>37</td>
      <td>1</td>
      <td>Travel_Rarely</td>
      <td>1373</td>
      <td>Research &amp; Development</td>
      <td>2</td>
      <td>2</td>
      <td>Other</td>
      <td>1</td>
      <td>4</td>
      <td>4</td>
      <td>Male</td>
      <td>92</td>
      <td>2</td>
      <td>1</td>
      <td>Laboratory Technician</td>
      <td>3</td>
      <td>Single</td>
      <td>2090</td>
      <td>2396</td>
      <td>6</td>
      <td>Y</td>
      <td>Yes</td>
      <td>15</td>
      <td>3</td>
      <td>2</td>
      <td>80</td>
      <td>0</td>
      <td>7</td>
      <td>3</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>33</td>
      <td>0</td>
      <td>Travel_Frequently</td>
      <td>1392</td>
      <td>Research &amp; Development</td>
      <td>3</td>
      <td>4</td>
      <td>Life Sciences</td>
      <td>1</td>
      <td>5</td>
      <td>4</td>
      <td>Female</td>
      <td>56</td>
      <td>3</td>
      <td>1</td>
      <td>Research Scientist</td>
      <td>3</td>
      <td>Married</td>
      <td>2909</td>
      <td>23159</td>
      <td>1</td>
      <td>Y</td>
      <td>Yes</td>
      <td>11</td>
      <td>3</td>
      <td>3</td>
      <td>80</td>
      <td>0</td>
      <td>8</td>
      <td>3</td>
      <td>3</td>
      <td>8</td>
      <td>7</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>27</td>
      <td>0</td>
      <td>Travel_Rarely</td>
      <td>591</td>
      <td>Research &amp; Development</td>
      <td>2</td>
      <td>1</td>
      <td>Medical</td>
      <td>1</td>
      <td>7</td>
      <td>1</td>
      <td>Male</td>
      <td>40</td>
      <td>3</td>
      <td>1</td>
      <td>Laboratory Technician</td>
      <td>2</td>
      <td>Married</td>
      <td>3468</td>
      <td>16632</td>
      <td>9</td>
      <td>Y</td>
      <td>No</td>
      <td>12</td>
      <td>3</td>
      <td>4</td>
      <td>80</td>
      <td>1</td>
      <td>6</td>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Droping unnecessary columns
df.drop(["EmployeeCount", "EmployeeNumber", "Over18", "StandardHours"], axis=1, inplace=True)

```


```python
df.shape
```




    (1470, 31)




```python
# Ordinal Encoding for ordinal variables
from sklearn.preprocessing import OrdinalEncoder
oe = OrdinalEncoder()
def ordinal_encode(df, column):
    df[column] = oe.fit_transform(df[column])
    return df

oe_col = ['BusinessTravel', 'Department', 'EducationField', 'Gender', 'JobRole', 'MaritalStatus', 'OverTime']
df=ordinal_encode(df, oe_col)
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Attrition</th>
      <th>BusinessTravel</th>
      <th>DailyRate</th>
      <th>Department</th>
      <th>DistanceFromHome</th>
      <th>Education</th>
      <th>EducationField</th>
      <th>EnvironmentSatisfaction</th>
      <th>Gender</th>
      <th>HourlyRate</th>
      <th>JobInvolvement</th>
      <th>JobLevel</th>
      <th>JobRole</th>
      <th>JobSatisfaction</th>
      <th>MaritalStatus</th>
      <th>MonthlyIncome</th>
      <th>MonthlyRate</th>
      <th>NumCompaniesWorked</th>
      <th>OverTime</th>
      <th>PercentSalaryHike</th>
      <th>PerformanceRating</th>
      <th>RelationshipSatisfaction</th>
      <th>StockOptionLevel</th>
      <th>TotalWorkingYears</th>
      <th>TrainingTimesLastYear</th>
      <th>WorkLifeBalance</th>
      <th>YearsAtCompany</th>
      <th>YearsInCurrentRole</th>
      <th>YearsSinceLastPromotion</th>
      <th>YearsWithCurrManager</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>41</td>
      <td>1</td>
      <td>2.0</td>
      <td>1102</td>
      <td>2.0</td>
      <td>1</td>
      <td>2</td>
      <td>1.0</td>
      <td>2</td>
      <td>0.0</td>
      <td>94</td>
      <td>3</td>
      <td>2</td>
      <td>7.0</td>
      <td>4</td>
      <td>2.0</td>
      <td>5993</td>
      <td>19479</td>
      <td>8</td>
      <td>1.0</td>
      <td>11</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>8</td>
      <td>0</td>
      <td>1</td>
      <td>6</td>
      <td>4</td>
      <td>0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>49</td>
      <td>0</td>
      <td>1.0</td>
      <td>279</td>
      <td>1.0</td>
      <td>8</td>
      <td>1</td>
      <td>1.0</td>
      <td>3</td>
      <td>1.0</td>
      <td>61</td>
      <td>2</td>
      <td>2</td>
      <td>6.0</td>
      <td>2</td>
      <td>1.0</td>
      <td>5130</td>
      <td>24907</td>
      <td>1</td>
      <td>0.0</td>
      <td>23</td>
      <td>4</td>
      <td>4</td>
      <td>1</td>
      <td>10</td>
      <td>3</td>
      <td>3</td>
      <td>10</td>
      <td>7</td>
      <td>1</td>
      <td>7</td>
    </tr>
    <tr>
      <th>2</th>
      <td>37</td>
      <td>1</td>
      <td>2.0</td>
      <td>1373</td>
      <td>1.0</td>
      <td>2</td>
      <td>2</td>
      <td>4.0</td>
      <td>4</td>
      <td>1.0</td>
      <td>92</td>
      <td>2</td>
      <td>1</td>
      <td>2.0</td>
      <td>3</td>
      <td>2.0</td>
      <td>2090</td>
      <td>2396</td>
      <td>6</td>
      <td>1.0</td>
      <td>15</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
      <td>7</td>
      <td>3</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>33</td>
      <td>0</td>
      <td>1.0</td>
      <td>1392</td>
      <td>1.0</td>
      <td>3</td>
      <td>4</td>
      <td>1.0</td>
      <td>4</td>
      <td>0.0</td>
      <td>56</td>
      <td>3</td>
      <td>1</td>
      <td>6.0</td>
      <td>3</td>
      <td>1.0</td>
      <td>2909</td>
      <td>23159</td>
      <td>1</td>
      <td>1.0</td>
      <td>11</td>
      <td>3</td>
      <td>3</td>
      <td>0</td>
      <td>8</td>
      <td>3</td>
      <td>3</td>
      <td>8</td>
      <td>7</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>27</td>
      <td>0</td>
      <td>2.0</td>
      <td>591</td>
      <td>1.0</td>
      <td>2</td>
      <td>1</td>
      <td>3.0</td>
      <td>1</td>
      <td>1.0</td>
      <td>40</td>
      <td>3</td>
      <td>1</td>
      <td>2.0</td>
      <td>2</td>
      <td>1.0</td>
      <td>3468</td>
      <td>16632</td>
      <td>9</td>
      <td>0.0</td>
      <td>12</td>
      <td>3</td>
      <td>4</td>
      <td>1</td>
      <td>6</td>
      <td>3</td>
      <td>3</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>



## Outliers Detection and Removal


```python
plt.figure(figsize=(20,30),facecolor='white')
plotnumber=1

for column in Numeric:
    if plotnumber<=28:
        ax=plt.subplot(7,4,plotnumber)
        sns.boxplot(df[column],color='g')
        plt.xlabel(column,fontsize=20)
    plotnumber+=1
plt.show()
```


    
![png](output_65_0.png)
    


### Features containing outliers
"MonthlyIncome", "NumCompaniesWorked", "PerformanceRating", "StockOptionLevel", "TotalWorkingYears", "TrainingTimesLastYear", "YearsAtCompany", "YearsInCurrentRole", "YearsSinceLastPromotion", "YearsWithCurrManager", "Attrition".


```python
from scipy.stats import zscore
z = np.abs(zscore(df))
threshold = 3
df1 = df[(z<3).all(axis = 1)]

print ("Shape of the dataframe before removing outliers: ", df.shape)
print ("Shape of the dataframe after removing outliers: ", df1.shape)
print ("Percentage of data loss post outlier removal: ", (df.shape[0]-df1.shape[0])/df.shape[0]*100)

df=df1.copy() # reassigning the changed dataframe name to our original dataframe name
```

    Shape of the dataframe before removing outliers:  (1470, 31)
    Shape of the dataframe after removing outliers:  (1387, 31)
    Percentage of data loss post outlier removal:  5.646258503401361
    

### Data Loss



```python
print("\033[1m"+'Percentage Data Loss :'+"\033[0m",((1470-1387)/1470)*100,'%')

```

    [1mPercentage Data Loss :[0m 5.646258503401361 %
    

### Feature selection and Engineering



##### 1. Skewness of features



```python
df.skew()

```




    Age                         0.472280
    Attrition                   1.805983
    BusinessTravel             -1.426774
    DailyRate                  -0.017078
    Department                  0.183919
    DistanceFromHome            0.954752
    Education                  -0.289024
    EducationField              0.544868
    EnvironmentSatisfaction    -0.325285
    Gender                     -0.417296
    HourlyRate                 -0.030481
    JobInvolvement             -0.501401
    JobLevel                    1.126075
    JobRole                    -0.386843
    JobSatisfaction            -0.345612
    MaritalStatus              -0.160952
    MonthlyIncome               1.544770
    MonthlyRate                 0.030596
    NumCompaniesWorked          1.037715
    OverTime                    0.954751
    PercentSalaryHike           0.800592
    PerformanceRating           1.931566
    RelationshipSatisfaction   -0.295686
    StockOptionLevel            0.962332
    TotalWorkingYears           1.034487
    TrainingTimesLastYear       0.577614
    WorkLifeBalance            -0.557100
    YearsAtCompany              1.248623
    YearsInCurrentRole          0.726675
    YearsSinceLastPromotion     1.756335
    YearsWithCurrManager        0.694506
    dtype: float64




```python
# Splitting data in target and dependent feature
X = df.drop(['Attrition'], axis =1)
Y = df['Attrition']
```

## Transforming skew data using power transform


```python
from sklearn.preprocessing import power_transform
df = power_transform(X)
df = pd.DataFrame(df, columns=X.columns)
df.skew()
```




    Age                        -0.004079
    BusinessTravel             -0.960583
    DailyRate                  -0.199742
    Department                  0.015095
    DistanceFromHome           -0.008149
    Education                  -0.103747
    EducationField             -0.008642
    EnvironmentSatisfaction    -0.205472
    Gender                     -0.417296
    HourlyRate                 -0.105678
    JobInvolvement             -0.018801
    JobLevel                    0.110769
    JobRole                    -0.337641
    JobSatisfaction            -0.217730
    MaritalStatus              -0.158253
    MonthlyIncome               0.027700
    MonthlyRate                -0.176560
    NumCompaniesWorked          0.016175
    OverTime                    0.954751
    PercentSalaryHike           0.112128
    PerformanceRating           0.000000
    RelationshipSatisfaction   -0.191406
    StockOptionLevel            0.089929
    TotalWorkingYears          -0.009666
    TrainingTimesLastYear       0.057949
    WorkLifeBalance            -0.011133
    YearsAtCompany             -0.025230
    YearsInCurrentRole         -0.069631
    YearsSinceLastPromotion     0.212301
    YearsWithCurrManager       -0.070570
    dtype: float64



### Comment :
- For Numeric features skewness is transform within permissible limit.
- For ordinal features & categorical features skew parameter irrevalent.


#### 2. Corrleation



```python
df.corr()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>BusinessTravel</th>
      <th>DailyRate</th>
      <th>Department</th>
      <th>DistanceFromHome</th>
      <th>Education</th>
      <th>EducationField</th>
      <th>EnvironmentSatisfaction</th>
      <th>Gender</th>
      <th>HourlyRate</th>
      <th>JobInvolvement</th>
      <th>JobLevel</th>
      <th>JobRole</th>
      <th>JobSatisfaction</th>
      <th>MaritalStatus</th>
      <th>MonthlyIncome</th>
      <th>MonthlyRate</th>
      <th>NumCompaniesWorked</th>
      <th>OverTime</th>
      <th>PercentSalaryHike</th>
      <th>PerformanceRating</th>
      <th>RelationshipSatisfaction</th>
      <th>StockOptionLevel</th>
      <th>TotalWorkingYears</th>
      <th>TrainingTimesLastYear</th>
      <th>WorkLifeBalance</th>
      <th>YearsAtCompany</th>
      <th>YearsInCurrentRole</th>
      <th>YearsSinceLastPromotion</th>
      <th>YearsWithCurrManager</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Age</th>
      <td>1.000000</td>
      <td>0.019607</td>
      <td>0.019864</td>
      <td>-0.036344</td>
      <td>-0.025855</td>
      <td>0.215520</td>
      <td>-0.037564</td>
      <td>0.013967</td>
      <td>-0.037163</td>
      <td>0.026203</td>
      <td>0.032323</td>
      <td>0.442350</td>
      <td>-0.116758</td>
      <td>0.010038</td>
      <td>-0.117182</td>
      <td>0.452513</td>
      <td>0.020538</td>
      <td>0.340022</td>
      <td>0.028332</td>
      <td>0.010488</td>
      <td>NaN</td>
      <td>0.037296</td>
      <td>0.089449</td>
      <td>0.652405</td>
      <td>-0.014951</td>
      <td>-0.016180</td>
      <td>0.207538</td>
      <td>0.145404</td>
      <td>0.114162</td>
      <td>0.142446</td>
    </tr>
    <tr>
      <th>BusinessTravel</th>
      <td>0.019607</td>
      <td>1.000000</td>
      <td>-0.001984</td>
      <td>-0.003560</td>
      <td>-0.007041</td>
      <td>-0.006468</td>
      <td>0.034658</td>
      <td>0.004183</td>
      <td>-0.011439</td>
      <td>0.026364</td>
      <td>0.018230</td>
      <td>0.003401</td>
      <td>-0.002615</td>
      <td>-0.033026</td>
      <td>0.010108</td>
      <td>0.030793</td>
      <td>-0.008138</td>
      <td>0.034013</td>
      <td>0.010934</td>
      <td>-0.019175</td>
      <td>NaN</td>
      <td>-0.036165</td>
      <td>-0.006092</td>
      <td>0.027298</td>
      <td>0.006192</td>
      <td>-0.017977</td>
      <td>-0.024021</td>
      <td>-0.035610</td>
      <td>-0.033148</td>
      <td>-0.032665</td>
    </tr>
    <tr>
      <th>DailyRate</th>
      <td>0.019864</td>
      <td>-0.001984</td>
      <td>1.000000</td>
      <td>-0.003546</td>
      <td>-0.006034</td>
      <td>-0.017504</td>
      <td>0.040993</td>
      <td>0.034324</td>
      <td>-0.003271</td>
      <td>0.015156</td>
      <td>0.041841</td>
      <td>0.015931</td>
      <td>-0.013156</td>
      <td>0.044460</td>
      <td>-0.076058</td>
      <td>0.029944</td>
      <td>-0.032890</td>
      <td>0.034923</td>
      <td>0.020045</td>
      <td>0.029183</td>
      <td>NaN</td>
      <td>0.005771</td>
      <td>0.049415</td>
      <td>0.042750</td>
      <td>0.005118</td>
      <td>-0.046550</td>
      <td>0.005391</td>
      <td>0.022143</td>
      <td>-0.035448</td>
      <td>0.005908</td>
    </tr>
    <tr>
      <th>Department</th>
      <td>-0.036344</td>
      <td>-0.003560</td>
      <td>-0.003546</td>
      <td>1.000000</td>
      <td>0.037834</td>
      <td>0.012780</td>
      <td>0.082525</td>
      <td>-0.013867</td>
      <td>-0.030950</td>
      <td>-0.000623</td>
      <td>-0.025121</td>
      <td>0.200829</td>
      <td>0.681597</td>
      <td>0.030615</td>
      <td>0.052696</td>
      <td>0.152234</td>
      <td>0.023941</td>
      <td>-0.033131</td>
      <td>0.015121</td>
      <td>-0.013541</td>
      <td>NaN</td>
      <td>-0.037572</td>
      <td>-0.000630</td>
      <td>-0.006833</td>
      <td>0.039938</td>
      <td>0.017807</td>
      <td>0.025457</td>
      <td>0.057817</td>
      <td>0.017699</td>
      <td>0.024241</td>
    </tr>
    <tr>
      <th>DistanceFromHome</th>
      <td>-0.025855</td>
      <td>-0.007041</td>
      <td>-0.006034</td>
      <td>0.037834</td>
      <td>1.000000</td>
      <td>0.002714</td>
      <td>0.021074</td>
      <td>-0.013409</td>
      <td>0.010557</td>
      <td>0.015607</td>
      <td>0.038096</td>
      <td>0.024038</td>
      <td>0.010044</td>
      <td>-0.020165</td>
      <td>-0.027285</td>
      <td>0.000545</td>
      <td>0.047736</td>
      <td>-0.010318</td>
      <td>0.036524</td>
      <td>0.034946</td>
      <td>NaN</td>
      <td>0.009379</td>
      <td>0.027082</td>
      <td>-0.012129</td>
      <td>-0.015334</td>
      <td>-0.030011</td>
      <td>0.006570</td>
      <td>0.013091</td>
      <td>-0.003873</td>
      <td>-0.002310</td>
    </tr>
    <tr>
      <th>Education</th>
      <td>0.215520</td>
      <td>-0.006468</td>
      <td>-0.017504</td>
      <td>0.012780</td>
      <td>0.002714</td>
      <td>1.000000</td>
      <td>-0.038405</td>
      <td>-0.026095</td>
      <td>-0.017807</td>
      <td>0.011105</td>
      <td>0.042166</td>
      <td>0.103834</td>
      <td>0.016548</td>
      <td>-0.005640</td>
      <td>-0.012237</td>
      <td>0.112084</td>
      <td>-0.018874</td>
      <td>0.136101</td>
      <td>-0.015248</td>
      <td>-0.002095</td>
      <td>NaN</td>
      <td>-0.004863</td>
      <td>0.025621</td>
      <td>0.150720</td>
      <td>-0.023039</td>
      <td>0.010164</td>
      <td>0.037921</td>
      <td>0.051072</td>
      <td>0.016076</td>
      <td>0.026651</td>
    </tr>
    <tr>
      <th>EducationField</th>
      <td>-0.037564</td>
      <td>0.034658</td>
      <td>0.040993</td>
      <td>0.082525</td>
      <td>0.021074</td>
      <td>-0.038405</td>
      <td>1.000000</td>
      <td>0.042609</td>
      <td>0.005059</td>
      <td>-0.004372</td>
      <td>-0.007969</td>
      <td>-0.026676</td>
      <td>0.050693</td>
      <td>-0.050693</td>
      <td>0.013433</td>
      <td>-0.020033</td>
      <td>-0.027785</td>
      <td>-0.010403</td>
      <td>0.010335</td>
      <td>0.000812</td>
      <td>NaN</td>
      <td>-0.018254</td>
      <td>-0.012936</td>
      <td>-0.001827</td>
      <td>0.054321</td>
      <td>0.034788</td>
      <td>0.004483</td>
      <td>0.004372</td>
      <td>0.023062</td>
      <td>0.028189</td>
    </tr>
    <tr>
      <th>EnvironmentSatisfaction</th>
      <td>0.013967</td>
      <td>0.004183</td>
      <td>0.034324</td>
      <td>-0.013867</td>
      <td>-0.013409</td>
      <td>-0.026095</td>
      <td>0.042609</td>
      <td>1.000000</td>
      <td>-0.014940</td>
      <td>-0.042512</td>
      <td>-0.020953</td>
      <td>0.010615</td>
      <td>-0.022464</td>
      <td>-0.009553</td>
      <td>-0.012356</td>
      <td>-0.011976</td>
      <td>0.036843</td>
      <td>0.011203</td>
      <td>0.058274</td>
      <td>-0.027743</td>
      <td>NaN</td>
      <td>0.016892</td>
      <td>0.024345</td>
      <td>-0.013356</td>
      <td>-0.018350</td>
      <td>0.030422</td>
      <td>0.012338</td>
      <td>0.029218</td>
      <td>0.038031</td>
      <td>0.006417</td>
    </tr>
    <tr>
      <th>Gender</th>
      <td>-0.037163</td>
      <td>-0.011439</td>
      <td>-0.003271</td>
      <td>-0.030950</td>
      <td>0.010557</td>
      <td>-0.017807</td>
      <td>0.005059</td>
      <td>-0.014940</td>
      <td>1.000000</td>
      <td>0.005618</td>
      <td>0.014878</td>
      <td>-0.058378</td>
      <td>-0.036436</td>
      <td>0.038130</td>
      <td>-0.056779</td>
      <td>-0.052340</td>
      <td>-0.047240</td>
      <td>-0.033345</td>
      <td>-0.051558</td>
      <td>0.010984</td>
      <td>NaN</td>
      <td>0.041439</td>
      <td>0.024390</td>
      <td>-0.049776</td>
      <td>-0.039213</td>
      <td>0.002726</td>
      <td>-0.046018</td>
      <td>-0.028101</td>
      <td>-0.016131</td>
      <td>-0.027972</td>
    </tr>
    <tr>
      <th>HourlyRate</th>
      <td>0.026203</td>
      <td>0.026364</td>
      <td>0.015156</td>
      <td>-0.000623</td>
      <td>0.015607</td>
      <td>0.011105</td>
      <td>-0.004372</td>
      <td>-0.042512</td>
      <td>0.005618</td>
      <td>1.000000</td>
      <td>0.051979</td>
      <td>-0.039909</td>
      <td>-0.023758</td>
      <td>-0.067797</td>
      <td>-0.008966</td>
      <td>-0.023613</td>
      <td>-0.011438</td>
      <td>0.019917</td>
      <td>-0.003232</td>
      <td>-0.015826</td>
      <td>NaN</td>
      <td>0.005207</td>
      <td>0.041329</td>
      <td>-0.012902</td>
      <td>-0.018396</td>
      <td>-0.013811</td>
      <td>-0.032827</td>
      <td>-0.035899</td>
      <td>-0.062271</td>
      <td>-0.022931</td>
    </tr>
    <tr>
      <th>JobInvolvement</th>
      <td>0.032323</td>
      <td>0.018230</td>
      <td>0.041841</td>
      <td>-0.025121</td>
      <td>0.038096</td>
      <td>0.042166</td>
      <td>-0.007969</td>
      <td>-0.020953</td>
      <td>0.014878</td>
      <td>0.051979</td>
      <td>1.000000</td>
      <td>-0.010769</td>
      <td>0.004055</td>
      <td>0.005571</td>
      <td>-0.048981</td>
      <td>-0.010613</td>
      <td>-0.003145</td>
      <td>0.006161</td>
      <td>0.002521</td>
      <td>-0.009987</td>
      <td>NaN</td>
      <td>0.038450</td>
      <td>0.036543</td>
      <td>0.013791</td>
      <td>-0.012595</td>
      <td>-0.008334</td>
      <td>0.023893</td>
      <td>0.023724</td>
      <td>-0.006630</td>
      <td>0.052822</td>
    </tr>
    <tr>
      <th>JobLevel</th>
      <td>0.442350</td>
      <td>0.003401</td>
      <td>0.015931</td>
      <td>0.200829</td>
      <td>0.024038</td>
      <td>0.103834</td>
      <td>-0.026676</td>
      <td>0.010615</td>
      <td>-0.058378</td>
      <td>-0.039909</td>
      <td>-0.010769</td>
      <td>1.000000</td>
      <td>-0.044347</td>
      <td>0.012351</td>
      <td>-0.074952</td>
      <td>0.901390</td>
      <td>0.059076</td>
      <td>0.172878</td>
      <td>0.002946</td>
      <td>-0.027772</td>
      <td>NaN</td>
      <td>0.001790</td>
      <td>0.051470</td>
      <td>0.704215</td>
      <td>-0.010041</td>
      <td>0.048855</td>
      <td>0.409496</td>
      <td>0.324336</td>
      <td>0.195445</td>
      <td>0.315914</td>
    </tr>
    <tr>
      <th>JobRole</th>
      <td>-0.116758</td>
      <td>-0.002615</td>
      <td>-0.013156</td>
      <td>0.681597</td>
      <td>0.010044</td>
      <td>0.016548</td>
      <td>0.050693</td>
      <td>-0.022464</td>
      <td>-0.036436</td>
      <td>-0.023758</td>
      <td>0.004055</td>
      <td>-0.044347</td>
      <td>1.000000</td>
      <td>0.015425</td>
      <td>0.063515</td>
      <td>-0.061166</td>
      <td>0.000150</td>
      <td>-0.064168</td>
      <td>0.043191</td>
      <td>0.007921</td>
      <td>NaN</td>
      <td>-0.022498</td>
      <td>-0.022612</td>
      <td>-0.135182</td>
      <td>0.004225</td>
      <td>0.012521</td>
      <td>-0.040080</td>
      <td>0.007195</td>
      <td>0.000737</td>
      <td>-0.016941</td>
    </tr>
    <tr>
      <th>JobSatisfaction</th>
      <td>0.010038</td>
      <td>-0.033026</td>
      <td>0.044460</td>
      <td>0.030615</td>
      <td>-0.020165</td>
      <td>-0.005640</td>
      <td>-0.050693</td>
      <td>-0.009553</td>
      <td>0.038130</td>
      <td>-0.067797</td>
      <td>0.005571</td>
      <td>0.012351</td>
      <td>0.015425</td>
      <td>1.000000</td>
      <td>0.022030</td>
      <td>0.009841</td>
      <td>-0.008176</td>
      <td>-0.045834</td>
      <td>0.027862</td>
      <td>0.017539</td>
      <td>NaN</td>
      <td>-0.011745</td>
      <td>0.006946</td>
      <td>-0.000852</td>
      <td>-0.018180</td>
      <td>-0.024821</td>
      <td>0.030234</td>
      <td>0.018021</td>
      <td>0.026805</td>
      <td>0.004270</td>
    </tr>
    <tr>
      <th>MaritalStatus</th>
      <td>-0.117182</td>
      <td>0.010108</td>
      <td>-0.076058</td>
      <td>0.052696</td>
      <td>-0.027285</td>
      <td>-0.012237</td>
      <td>0.013433</td>
      <td>-0.012356</td>
      <td>-0.056779</td>
      <td>-0.008966</td>
      <td>-0.048981</td>
      <td>-0.074952</td>
      <td>0.063515</td>
      <td>0.022030</td>
      <td>1.000000</td>
      <td>-0.077609</td>
      <td>0.029672</td>
      <td>-0.055310</td>
      <td>-0.014736</td>
      <td>0.013717</td>
      <td>NaN</td>
      <td>0.025140</td>
      <td>-0.741869</td>
      <td>-0.098675</td>
      <td>0.015749</td>
      <td>0.019958</td>
      <td>-0.066987</td>
      <td>-0.054949</td>
      <td>-0.008255</td>
      <td>-0.049952</td>
    </tr>
    <tr>
      <th>MonthlyIncome</th>
      <td>0.452513</td>
      <td>0.030793</td>
      <td>0.029944</td>
      <td>0.152234</td>
      <td>0.000545</td>
      <td>0.112084</td>
      <td>-0.020033</td>
      <td>-0.011976</td>
      <td>-0.052340</td>
      <td>-0.023613</td>
      <td>-0.010613</td>
      <td>0.901390</td>
      <td>-0.061166</td>
      <td>0.009841</td>
      <td>-0.077609</td>
      <td>1.000000</td>
      <td>0.050687</td>
      <td>0.189833</td>
      <td>0.013261</td>
      <td>-0.026381</td>
      <td>NaN</td>
      <td>-0.007392</td>
      <td>0.052393</td>
      <td>0.716232</td>
      <td>-0.034842</td>
      <td>0.032043</td>
      <td>0.416465</td>
      <td>0.343024</td>
      <td>0.203459</td>
      <td>0.320449</td>
    </tr>
    <tr>
      <th>MonthlyRate</th>
      <td>0.020538</td>
      <td>-0.008138</td>
      <td>-0.032890</td>
      <td>0.023941</td>
      <td>0.047736</td>
      <td>-0.018874</td>
      <td>-0.027785</td>
      <td>0.036843</td>
      <td>-0.047240</td>
      <td>-0.011438</td>
      <td>-0.003145</td>
      <td>0.059076</td>
      <td>0.000150</td>
      <td>-0.008176</td>
      <td>0.029672</td>
      <td>0.050687</td>
      <td>1.000000</td>
      <td>0.019063</td>
      <td>0.004033</td>
      <td>-0.011841</td>
      <td>NaN</td>
      <td>-0.003920</td>
      <td>-0.046690</td>
      <td>0.006912</td>
      <td>0.019786</td>
      <td>0.001548</td>
      <td>-0.034877</td>
      <td>-0.008670</td>
      <td>-0.019588</td>
      <td>-0.033583</td>
    </tr>
    <tr>
      <th>NumCompaniesWorked</th>
      <td>0.340022</td>
      <td>0.034013</td>
      <td>0.034923</td>
      <td>-0.033131</td>
      <td>-0.010318</td>
      <td>0.136101</td>
      <td>-0.010403</td>
      <td>0.011203</td>
      <td>-0.033345</td>
      <td>0.019917</td>
      <td>0.006161</td>
      <td>0.172878</td>
      <td>-0.064168</td>
      <td>-0.045834</td>
      <td>-0.055310</td>
      <td>0.189833</td>
      <td>0.019063</td>
      <td>1.000000</td>
      <td>-0.008714</td>
      <td>0.001821</td>
      <td>NaN</td>
      <td>0.041253</td>
      <td>0.038411</td>
      <td>0.322501</td>
      <td>-0.056832</td>
      <td>0.020077</td>
      <td>-0.178518</td>
      <td>-0.136304</td>
      <td>-0.082304</td>
      <td>-0.154424</td>
    </tr>
    <tr>
      <th>OverTime</th>
      <td>0.028332</td>
      <td>0.010934</td>
      <td>0.020045</td>
      <td>0.015121</td>
      <td>0.036524</td>
      <td>-0.015248</td>
      <td>0.010335</td>
      <td>0.058274</td>
      <td>-0.051558</td>
      <td>-0.003232</td>
      <td>0.002521</td>
      <td>0.002946</td>
      <td>0.043191</td>
      <td>0.027862</td>
      <td>-0.014736</td>
      <td>0.013261</td>
      <td>0.004033</td>
      <td>-0.008714</td>
      <td>1.000000</td>
      <td>-0.011486</td>
      <td>NaN</td>
      <td>0.048337</td>
      <td>-0.011216</td>
      <td>0.010003</td>
      <td>-0.076271</td>
      <td>-0.035715</td>
      <td>-0.030449</td>
      <td>-0.031265</td>
      <td>-0.010815</td>
      <td>-0.030906</td>
    </tr>
    <tr>
      <th>PercentSalaryHike</th>
      <td>0.010488</td>
      <td>-0.019175</td>
      <td>0.029183</td>
      <td>-0.013541</td>
      <td>0.034946</td>
      <td>-0.002095</td>
      <td>0.000812</td>
      <td>-0.027743</td>
      <td>0.010984</td>
      <td>-0.015826</td>
      <td>-0.009987</td>
      <td>-0.027772</td>
      <td>0.007921</td>
      <td>0.017539</td>
      <td>0.013717</td>
      <td>-0.026381</td>
      <td>-0.011841</td>
      <td>0.001821</td>
      <td>-0.011486</td>
      <td>1.000000</td>
      <td>NaN</td>
      <td>-0.032962</td>
      <td>0.021635</td>
      <td>-0.021813</td>
      <td>-0.011397</td>
      <td>-0.015558</td>
      <td>-0.053612</td>
      <td>-0.028763</td>
      <td>-0.055194</td>
      <td>-0.028292</td>
    </tr>
    <tr>
      <th>PerformanceRating</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>RelationshipSatisfaction</th>
      <td>0.037296</td>
      <td>-0.036165</td>
      <td>0.005771</td>
      <td>-0.037572</td>
      <td>0.009379</td>
      <td>-0.004863</td>
      <td>-0.018254</td>
      <td>0.016892</td>
      <td>0.041439</td>
      <td>0.005207</td>
      <td>0.038450</td>
      <td>0.001790</td>
      <td>-0.022498</td>
      <td>-0.011745</td>
      <td>0.025140</td>
      <td>-0.007392</td>
      <td>-0.003920</td>
      <td>0.041253</td>
      <td>0.048337</td>
      <td>-0.032962</td>
      <td>NaN</td>
      <td>1.000000</td>
      <td>-0.056524</td>
      <td>-0.007637</td>
      <td>-0.001554</td>
      <td>0.021454</td>
      <td>-0.019388</td>
      <td>-0.027391</td>
      <td>0.010034</td>
      <td>-0.006855</td>
    </tr>
    <tr>
      <th>StockOptionLevel</th>
      <td>0.089449</td>
      <td>-0.006092</td>
      <td>0.049415</td>
      <td>-0.000630</td>
      <td>0.027082</td>
      <td>0.025621</td>
      <td>-0.012936</td>
      <td>0.024345</td>
      <td>0.024390</td>
      <td>0.041329</td>
      <td>0.036543</td>
      <td>0.051470</td>
      <td>-0.022612</td>
      <td>0.006946</td>
      <td>-0.741869</td>
      <td>0.052393</td>
      <td>-0.046690</td>
      <td>0.038411</td>
      <td>-0.011216</td>
      <td>0.021635</td>
      <td>NaN</td>
      <td>-0.056524</td>
      <td>1.000000</td>
      <td>0.066322</td>
      <td>0.008981</td>
      <td>-0.013760</td>
      <td>0.071910</td>
      <td>0.075323</td>
      <td>0.029988</td>
      <td>0.069315</td>
    </tr>
    <tr>
      <th>TotalWorkingYears</th>
      <td>0.652405</td>
      <td>0.027298</td>
      <td>0.042750</td>
      <td>-0.006833</td>
      <td>-0.012129</td>
      <td>0.150720</td>
      <td>-0.001827</td>
      <td>-0.013356</td>
      <td>-0.049776</td>
      <td>-0.012902</td>
      <td>0.013791</td>
      <td>0.704215</td>
      <td>-0.135182</td>
      <td>-0.000852</td>
      <td>-0.098675</td>
      <td>0.716232</td>
      <td>0.006912</td>
      <td>0.322501</td>
      <td>0.010003</td>
      <td>-0.021813</td>
      <td>NaN</td>
      <td>-0.007637</td>
      <td>0.066322</td>
      <td>1.000000</td>
      <td>-0.019417</td>
      <td>0.010194</td>
      <td>0.532838</td>
      <td>0.423676</td>
      <td>0.262110</td>
      <td>0.430605</td>
    </tr>
    <tr>
      <th>TrainingTimesLastYear</th>
      <td>-0.014951</td>
      <td>0.006192</td>
      <td>0.005118</td>
      <td>0.039938</td>
      <td>-0.015334</td>
      <td>-0.023039</td>
      <td>0.054321</td>
      <td>-0.018350</td>
      <td>-0.039213</td>
      <td>-0.018396</td>
      <td>-0.012595</td>
      <td>-0.010041</td>
      <td>0.004225</td>
      <td>-0.018180</td>
      <td>0.015749</td>
      <td>-0.034842</td>
      <td>0.019786</td>
      <td>-0.056832</td>
      <td>-0.076271</td>
      <td>-0.011397</td>
      <td>NaN</td>
      <td>-0.001554</td>
      <td>0.008981</td>
      <td>-0.019417</td>
      <td>1.000000</td>
      <td>0.029674</td>
      <td>-0.002893</td>
      <td>-0.000389</td>
      <td>0.018813</td>
      <td>-0.008266</td>
    </tr>
    <tr>
      <th>WorkLifeBalance</th>
      <td>-0.016180</td>
      <td>-0.017977</td>
      <td>-0.046550</td>
      <td>0.017807</td>
      <td>-0.030011</td>
      <td>0.010164</td>
      <td>0.034788</td>
      <td>0.030422</td>
      <td>0.002726</td>
      <td>-0.013811</td>
      <td>-0.008334</td>
      <td>0.048855</td>
      <td>0.012521</td>
      <td>-0.024821</td>
      <td>0.019958</td>
      <td>0.032043</td>
      <td>0.001548</td>
      <td>0.020077</td>
      <td>-0.035715</td>
      <td>-0.015558</td>
      <td>NaN</td>
      <td>0.021454</td>
      <td>-0.013760</td>
      <td>0.010194</td>
      <td>0.029674</td>
      <td>1.000000</td>
      <td>0.012999</td>
      <td>0.023079</td>
      <td>0.007065</td>
      <td>-0.006078</td>
    </tr>
    <tr>
      <th>YearsAtCompany</th>
      <td>0.207538</td>
      <td>-0.024021</td>
      <td>0.005391</td>
      <td>0.025457</td>
      <td>0.006570</td>
      <td>0.037921</td>
      <td>0.004483</td>
      <td>0.012338</td>
      <td>-0.046018</td>
      <td>-0.032827</td>
      <td>0.023893</td>
      <td>0.409496</td>
      <td>-0.040080</td>
      <td>0.030234</td>
      <td>-0.066987</td>
      <td>0.416465</td>
      <td>-0.034877</td>
      <td>-0.178518</td>
      <td>-0.030449</td>
      <td>-0.053612</td>
      <td>NaN</td>
      <td>-0.019388</td>
      <td>0.071910</td>
      <td>0.532838</td>
      <td>-0.002893</td>
      <td>0.012999</td>
      <td>1.000000</td>
      <td>0.835352</td>
      <td>0.486029</td>
      <td>0.835219</td>
    </tr>
    <tr>
      <th>YearsInCurrentRole</th>
      <td>0.145404</td>
      <td>-0.035610</td>
      <td>0.022143</td>
      <td>0.057817</td>
      <td>0.013091</td>
      <td>0.051072</td>
      <td>0.004372</td>
      <td>0.029218</td>
      <td>-0.028101</td>
      <td>-0.035899</td>
      <td>0.023724</td>
      <td>0.324336</td>
      <td>0.007195</td>
      <td>0.018021</td>
      <td>-0.054949</td>
      <td>0.343024</td>
      <td>-0.008670</td>
      <td>-0.136304</td>
      <td>-0.031265</td>
      <td>-0.028763</td>
      <td>NaN</td>
      <td>-0.027391</td>
      <td>0.075323</td>
      <td>0.423676</td>
      <td>-0.000389</td>
      <td>0.023079</td>
      <td>0.835352</td>
      <td>1.000000</td>
      <td>0.482746</td>
      <td>0.729727</td>
    </tr>
    <tr>
      <th>YearsSinceLastPromotion</th>
      <td>0.114162</td>
      <td>-0.033148</td>
      <td>-0.035448</td>
      <td>0.017699</td>
      <td>-0.003873</td>
      <td>0.016076</td>
      <td>0.023062</td>
      <td>0.038031</td>
      <td>-0.016131</td>
      <td>-0.062271</td>
      <td>-0.006630</td>
      <td>0.195445</td>
      <td>0.000737</td>
      <td>0.026805</td>
      <td>-0.008255</td>
      <td>0.203459</td>
      <td>-0.019588</td>
      <td>-0.082304</td>
      <td>-0.010815</td>
      <td>-0.055194</td>
      <td>NaN</td>
      <td>0.010034</td>
      <td>0.029988</td>
      <td>0.262110</td>
      <td>0.018813</td>
      <td>0.007065</td>
      <td>0.486029</td>
      <td>0.482746</td>
      <td>1.000000</td>
      <td>0.456672</td>
    </tr>
    <tr>
      <th>YearsWithCurrManager</th>
      <td>0.142446</td>
      <td>-0.032665</td>
      <td>0.005908</td>
      <td>0.024241</td>
      <td>-0.002310</td>
      <td>0.026651</td>
      <td>0.028189</td>
      <td>0.006417</td>
      <td>-0.027972</td>
      <td>-0.022931</td>
      <td>0.052822</td>
      <td>0.315914</td>
      <td>-0.016941</td>
      <td>0.004270</td>
      <td>-0.049952</td>
      <td>0.320449</td>
      <td>-0.033583</td>
      <td>-0.154424</td>
      <td>-0.030906</td>
      <td>-0.028292</td>
      <td>NaN</td>
      <td>-0.006855</td>
      <td>0.069315</td>
      <td>0.430605</td>
      <td>-0.008266</td>
      <td>-0.006078</td>
      <td>0.835219</td>
      <td>0.729727</td>
      <td>0.456672</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
upper_triangle = np.triu(df.corr())
plt.figure(figsize=(25,15))
sns.heatmap(df.corr(), vmin=-1, vmax=1, annot=True, square=True, fmt='0.3f', 
            annot_kws={'size':10}, cmap="gist_stern", mask=upper_triangle)
plt.xticks(fontsize=12)
plt.yticks(fontsize=12)
plt.show()
```


    
![png](output_77_0.png)
    



```python
plt.figure(figsize = (18,6))
df1.corr()['Attrition'].drop(['Attrition']).plot(kind='bar',color = 'c')
plt.xlabel('Features',fontsize=15)
plt.ylabel('Attrition',fontsize=15)
plt.title('Correlation of features with Target Variable Attrition',fontsize = 18)
plt.show()

```


    
![png](output_78_0.png)
    


### Comment:
- Age, JobLevel, MonthlyIncome is highly positively correlated with TotalWorkingYears.
- JobLevel is highly positively correlated with the MonthlyIncome.
- PercentSalaryHike is highly positively correlated with the column PerformanceRating.



#### 3. Checking Multicollinearity between features using variance_inflation_factor


```python
from statsmodels.stats.outliers_influence import variance_inflation_factor
vif= pd.DataFrame()
vif['VIF']= [variance_inflation_factor(df.values,i) for i in range(df.shape[1])]
vif['Features']= df.columns
vif
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>VIF</th>
      <th>Features</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.930457</td>
      <td>Age</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.014314</td>
      <td>BusinessTravel</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.025841</td>
      <td>DailyRate</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2.172093</td>
      <td>Department</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1.017385</td>
      <td>DistanceFromHome</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1.065266</td>
      <td>Education</td>
    </tr>
    <tr>
      <th>6</th>
      <td>1.030480</td>
      <td>EducationField</td>
    </tr>
    <tr>
      <th>7</th>
      <td>1.024396</td>
      <td>EnvironmentSatisfaction</td>
    </tr>
    <tr>
      <th>8</th>
      <td>1.024366</td>
      <td>Gender</td>
    </tr>
    <tr>
      <th>9</th>
      <td>1.024189</td>
      <td>HourlyRate</td>
    </tr>
    <tr>
      <th>10</th>
      <td>1.020167</td>
      <td>JobInvolvement</td>
    </tr>
    <tr>
      <th>11</th>
      <td>5.976707</td>
      <td>JobLevel</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2.023213</td>
      <td>JobRole</td>
    </tr>
    <tr>
      <th>13</th>
      <td>1.023909</td>
      <td>JobSatisfaction</td>
    </tr>
    <tr>
      <th>14</th>
      <td>2.298943</td>
      <td>MaritalStatus</td>
    </tr>
    <tr>
      <th>15</th>
      <td>5.842828</td>
      <td>MonthlyIncome</td>
    </tr>
    <tr>
      <th>16</th>
      <td>1.022108</td>
      <td>MonthlyRate</td>
    </tr>
    <tr>
      <th>17</th>
      <td>1.426763</td>
      <td>NumCompaniesWorked</td>
    </tr>
    <tr>
      <th>18</th>
      <td>1.028400</td>
      <td>OverTime</td>
    </tr>
    <tr>
      <th>19</th>
      <td>1.016867</td>
      <td>PercentSalaryHike</td>
    </tr>
    <tr>
      <th>20</th>
      <td>NaN</td>
      <td>PerformanceRating</td>
    </tr>
    <tr>
      <th>21</th>
      <td>1.022260</td>
      <td>RelationshipSatisfaction</td>
    </tr>
    <tr>
      <th>22</th>
      <td>2.279101</td>
      <td>StockOptionLevel</td>
    </tr>
    <tr>
      <th>23</th>
      <td>4.093506</td>
      <td>TotalWorkingYears</td>
    </tr>
    <tr>
      <th>24</th>
      <td>1.025519</td>
      <td>TrainingTimesLastYear</td>
    </tr>
    <tr>
      <th>25</th>
      <td>1.017093</td>
      <td>WorkLifeBalance</td>
    </tr>
    <tr>
      <th>26</th>
      <td>6.296064</td>
      <td>YearsAtCompany</td>
    </tr>
    <tr>
      <th>27</th>
      <td>3.513852</td>
      <td>YearsInCurrentRole</td>
    </tr>
    <tr>
      <th>28</th>
      <td>1.373189</td>
      <td>YearsSinceLastPromotion</td>
    </tr>
    <tr>
      <th>29</th>
      <td>3.433437</td>
      <td>YearsWithCurrManager</td>
    </tr>
  </tbody>
</table>
</div>



### Comment :
- We can see that multicollinerity is within permissible limit of 10.



### Balancing using SMOTE
As data is Imbalanced in nature we will need to balance target variable.


```python
from imblearn.over_sampling import SMOTE
# Oversampleing using SMOTE Techniques
oversample = SMOTE()
X, Y = oversample.fit_resample(X, Y)
```


```python
Y.value_counts()
```




    1    1158
    0    1158
    Name: Attrition, dtype: int64



### Standard Scaling


```python
from sklearn.preprocessing import StandardScaler
scaler= StandardScaler()
X_scale = scaler.fit_transform(X)
```


```python
from sklearn.decomposition import PCA
pca = PCA()
#plot the graph to find the principal components
x_pca = pca.fit_transform(X_scale)
plt.figure(figsize=(10,10))
plt.plot(np.cumsum(pca.explained_variance_ratio_), 'ro-')
plt.xlabel('Number of Components')
plt.ylabel('Variance %')
plt.title('Explained variance Ratio')
plt.grid()
```


    
![png](output_86_0.png)
    


### Comment -
- AS per the graph, we can see that 21 principal components attribute for 90% of variation in the data. We shall pick the first 21 components for our prediction


```python
pca_new = PCA(n_components=21)
x_new = pca_new.fit_transform(X_scale)
```


```python
principle_x=pd.DataFrame(x_new,columns=np.arange(21))

```

## Machine Learning Model Building


```python
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, confusion_matrix,classification_report,f1_score
```


```python
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.ensemble import BaggingClassifier
```


```python
X_train, X_test, Y_train, Y_test = train_test_split(principle_x, Y, random_state=42, test_size=.33)
print('Training feature matrix size:',X_train.shape)
print('Training target vector size:',Y_train.shape)
print('Test feature matrix size:',X_test.shape)
print('Test target vector size:',Y_test.shape)
```

    Training feature matrix size: (1551, 21)
    Training target vector size: (1551,)
    Test feature matrix size: (765, 21)
    Test target vector size: (765,)
    

## Finding best Random state


```python
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix,classification_report,f1_score
maxAccu=0
maxRS=0
for i in range(1,250):
    X_train,X_test,Y_train,Y_test = train_test_split(principle_x,Y,test_size = 0.33, random_state=i)
    log_reg=LogisticRegression()
    log_reg.fit(X_train,Y_train)
    y_pred=log_reg.predict(X_test)
    acc=accuracy_score(Y_test,y_pred)
    if acc>maxAccu:
        maxAccu=acc
        maxRS=i
print('Best accuracy is', maxAccu ,'on Random_state', maxRS)
```

    Best accuracy is 0.8627450980392157 on Random_state 31
    


```python
X_train, X_test, Y_train, Y_test = train_test_split(principle_x, Y, random_state=31, test_size=.33)
log_reg=LogisticRegression()
log_reg.fit(X_train,Y_train)
y_pred=log_reg.predict(X_test)
print('\033[1m'+'Logistics Regression Evaluation'+'\033[0m')
print('\n')
print('\033[1m'+'Accuracy Score of Logistics Regression :'+'\033[0m', accuracy_score(Y_test, y_pred))
print('\n')
print('\033[1m'+'Confusion matrix of Logistics Regression :'+'\033[0m \n',confusion_matrix(Y_test, y_pred))
print('\n')
print('\033[1m'+'classification Report of Logistics Regression'+'\033[0m \n',classification_report(Y_test, y_pred))

```

    [1mLogistics Regression Evaluation[0m
    
    
    [1mAccuracy Score of Logistics Regression :[0m 0.8627450980392157
    
    
    [1mConfusion matrix of Logistics Regression :[0m 
     [[332  52]
     [ 53 328]]
    
    
    [1mclassification Report of Logistics Regression[0m 
                   precision    recall  f1-score   support
    
               0       0.86      0.86      0.86       384
               1       0.86      0.86      0.86       381
    
        accuracy                           0.86       765
       macro avg       0.86      0.86      0.86       765
    weighted avg       0.86      0.86      0.86       765
    
    

## Finding Optimal value of n_neighbors for KNN


```python
from sklearn import neighbors
from math import sqrt
from sklearn.metrics import mean_squared_error
rmse_val = [] #to store rmse values for different k
for K in range(30):
    K = K+1
    model = neighbors.KNeighborsClassifier(n_neighbors = K)

    model.fit(X_train,Y_train)  #fit the model
    y_pred=model.predict(X_test) #make prediction on test set
    error = sqrt(mean_squared_error(Y_test,y_pred)) #calculate rmse
    rmse_val.append(error) #store rmse values
    print('RMSE value for k= ' , K , 'is:', error)
```

    RMSE value for k=  1 is: 0.3633540199183844
    RMSE value for k=  2 is: 0.29814239699997197
    RMSE value for k=  3 is: 0.39107694443752145
    RMSE value for k=  4 is: 0.34108630767160053
    RMSE value for k=  5 is: 0.3894020890135344
    RMSE value for k=  6 is: 0.3704792868174742
    RMSE value for k=  7 is: 0.40260589075170505
    RMSE value for k=  8 is: 0.38433373297259976
    RMSE value for k=  9 is: 0.4262620630612449
    RMSE value for k=  10 is: 0.4106427291215469
    RMSE value for k=  11 is: 0.4353647708073435
    RMSE value for k=  12 is: 0.42008402520840293
    RMSE value for k=  13 is: 0.4323518296193083
    RMSE value for k=  14 is: 0.41539020162714857
    RMSE value for k=  15 is: 0.4398454868332534
    RMSE value for k=  16 is: 0.4231843183770654
    RMSE value for k=  17 is: 0.44428101570406164
    RMSE value for k=  18 is: 0.4277926319464986
    RMSE value for k=  19 is: 0.4338609156373123
    RMSE value for k=  20 is: 0.4338609156373123
    RMSE value for k=  21 is: 0.44132894968500014
    RMSE value for k=  22 is: 0.4338609156373123
    RMSE value for k=  23 is: 0.4486726975674848
    RMSE value for k=  24 is: 0.4353647708073435
    RMSE value for k=  25 is: 0.4486726975674848
    RMSE value for k=  26 is: 0.4338609156373123
    RMSE value for k=  27 is: 0.44132894968500014
    RMSE value for k=  28 is: 0.4368634491492901
    RMSE value for k=  29 is: 0.44132894968500014
    RMSE value for k=  30 is: 0.4398454868332534
    


```python
#plotting the rmse values against k values -
plt.figure(figsize = (8,6))
plt.plot(range(30), rmse_val, color='blue', linestyle='dashed', marker='o', markerfacecolor='green', markersize=10)

```




    [<matplotlib.lines.Line2D at 0x266431b36a0>]




    
![png](output_99_1.png)
    


#### Comment-
- At k= 2, we get the minimum RMSE value which approximately 0.30032661958503204, and shoots up on further increasing the k value. We can safely say that k=2 will give us the best result in this case

## Applying other classification algorithm


```python
model=[
        SVC(),
        GaussianNB(),
        DecisionTreeClassifier(),
        KNeighborsClassifier(n_neighbors = 22),
        RandomForestClassifier(),
        AdaBoostClassifier(),
        GradientBoostingClassifier(),
        BaggingClassifier()]

for m in model:
    m.fit(X_train,Y_train)
    y_pred=m.predict(X_test)
    print('\033[1m'+'Classification ML Algorithm Evaluation Matrix',m,'is' +'\033[0m')
    print('\n')
    print('\033[1m'+'Accuracy Score :'+'\033[0m\n', accuracy_score(Y_test, y_pred))
    print('\n')
    print('\033[1m'+'Confusion matrix :'+'\033[0m \n',confusion_matrix(Y_test, y_pred))
    print('\n')
    print('\033[1m'+'Classification Report :'+'\033[0m \n',classification_report(Y_test, y_pred))
    print('\n')
    print('=================================================')
```

    [1mClassification ML Algorithm Evaluation Matrix SVC() is[0m
    
    
    [1mAccuracy Score :[0m
     0.9254901960784314
    
    
    [1mConfusion matrix :[0m 
     [[357  27]
     [ 30 351]]
    
    
    [1mClassification Report :[0m 
                   precision    recall  f1-score   support
    
               0       0.92      0.93      0.93       384
               1       0.93      0.92      0.92       381
    
        accuracy                           0.93       765
       macro avg       0.93      0.93      0.93       765
    weighted avg       0.93      0.93      0.93       765
    
    
    
    =================================================
    [1mClassification ML Algorithm Evaluation Matrix GaussianNB() is[0m
    
    
    [1mAccuracy Score :[0m
     0.8418300653594771
    
    
    [1mConfusion matrix :[0m 
     [[324  60]
     [ 61 320]]
    
    
    [1mClassification Report :[0m 
                   precision    recall  f1-score   support
    
               0       0.84      0.84      0.84       384
               1       0.84      0.84      0.84       381
    
        accuracy                           0.84       765
       macro avg       0.84      0.84      0.84       765
    weighted avg       0.84      0.84      0.84       765
    
    
    
    =================================================
    [1mClassification ML Algorithm Evaluation Matrix DecisionTreeClassifier() is[0m
    
    
    [1mAccuracy Score :[0m
     0.7869281045751634
    
    
    [1mConfusion matrix :[0m 
     [[306  78]
     [ 85 296]]
    
    
    [1mClassification Report :[0m 
                   precision    recall  f1-score   support
    
               0       0.78      0.80      0.79       384
               1       0.79      0.78      0.78       381
    
        accuracy                           0.79       765
       macro avg       0.79      0.79      0.79       765
    weighted avg       0.79      0.79      0.79       765
    
    
    
    =================================================
    [1mClassification ML Algorithm Evaluation Matrix KNeighborsClassifier(n_neighbors=22) is[0m
    
    
    [1mAccuracy Score :[0m
     0.8117647058823529
    
    
    [1mConfusion matrix :[0m 
     [[257 127]
     [ 17 364]]
    
    
    [1mClassification Report :[0m 
                   precision    recall  f1-score   support
    
               0       0.94      0.67      0.78       384
               1       0.74      0.96      0.83       381
    
        accuracy                           0.81       765
       macro avg       0.84      0.81      0.81       765
    weighted avg       0.84      0.81      0.81       765
    
    
    
    =================================================
    [1mClassification ML Algorithm Evaluation Matrix RandomForestClassifier() is[0m
    
    
    [1mAccuracy Score :[0m
     0.8928104575163399
    
    
    [1mConfusion matrix :[0m 
     [[348  36]
     [ 46 335]]
    
    
    [1mClassification Report :[0m 
                   precision    recall  f1-score   support
    
               0       0.88      0.91      0.89       384
               1       0.90      0.88      0.89       381
    
        accuracy                           0.89       765
       macro avg       0.89      0.89      0.89       765
    weighted avg       0.89      0.89      0.89       765
    
    
    
    =================================================
    [1mClassification ML Algorithm Evaluation Matrix AdaBoostClassifier() is[0m
    
    
    [1mAccuracy Score :[0m
     0.8431372549019608
    
    
    [1mConfusion matrix :[0m 
     [[318  66]
     [ 54 327]]
    
    
    [1mClassification Report :[0m 
                   precision    recall  f1-score   support
    
               0       0.85      0.83      0.84       384
               1       0.83      0.86      0.84       381
    
        accuracy                           0.84       765
       macro avg       0.84      0.84      0.84       765
    weighted avg       0.84      0.84      0.84       765
    
    
    
    =================================================
    [1mClassification ML Algorithm Evaluation Matrix GradientBoostingClassifier() is[0m
    
    
    [1mAccuracy Score :[0m
     0.8849673202614379
    
    
    [1mConfusion matrix :[0m 
     [[339  45]
     [ 43 338]]
    
    
    [1mClassification Report :[0m 
                   precision    recall  f1-score   support
    
               0       0.89      0.88      0.89       384
               1       0.88      0.89      0.88       381
    
        accuracy                           0.88       765
       macro avg       0.88      0.88      0.88       765
    weighted avg       0.88      0.88      0.88       765
    
    
    
    =================================================
    [1mClassification ML Algorithm Evaluation Matrix BaggingClassifier() is[0m
    
    
    [1mAccuracy Score :[0m
     0.8549019607843137
    
    
    [1mConfusion matrix :[0m 
     [[338  46]
     [ 65 316]]
    
    
    [1mClassification Report :[0m 
                   precision    recall  f1-score   support
    
               0       0.84      0.88      0.86       384
               1       0.87      0.83      0.85       381
    
        accuracy                           0.85       765
       macro avg       0.86      0.85      0.85       765
    weighted avg       0.86      0.85      0.85       765
    
    
    
    =================================================
    

## CrossValidation :



```python
from sklearn.model_selection import cross_val_score
model=[LogisticRegression(),
        SVC(),
        GaussianNB(),
        DecisionTreeClassifier(),
        KNeighborsClassifier(n_neighbors = 12),
        RandomForestClassifier(),
        AdaBoostClassifier(),
        GradientBoostingClassifier(),
        BaggingClassifier()]

for m in model:
    score = cross_val_score(m, X, Y, cv =5)
    print('\n')
    print('\033[1m'+'Cross Validation Score', m, ':'+'\033[0m\n')
    print("Score :" ,score)
    print("Mean Score :",score.mean())
    print("Std deviation :",score.std())
    print('\n')
    print('=================================================')
```

    
    
    [1mCross Validation Score LogisticRegression() :[0m
    
    Score : [0.6637931  0.71922246 0.69978402 0.67386609 0.6825054 ]
    Mean Score : 0.687834214642139
    Std deviation : 0.019644335833164942
    
    
    =================================================
    
    
    [1mCross Validation Score SVC() :[0m
    
    Score : [0.57327586 0.65442765 0.60907127 0.59179266 0.587473  ]
    Mean Score : 0.6032080881805317
    Std deviation : 0.02804162336069972
    
    
    =================================================
    
    
    [1mCross Validation Score GaussianNB() :[0m
    
    Score : [0.66594828 0.79913607 0.7537797  0.7537797  0.72786177]
    Mean Score : 0.740101102256647
    Std deviation : 0.043606830072476475
    
    
    =================================================
    
    
    [1mCross Validation Score DecisionTreeClassifier() :[0m
    
    Score : [0.67672414 0.88984881 0.90712743 0.85529158 0.89416847]
    Mean Score : 0.8446320846056453
    Std deviation : 0.0856863782378267
    
    
    =================================================
    
    
    [1mCross Validation Score KNeighborsClassifier(n_neighbors=12) :[0m
    
    Score : [0.73275862 0.71706263 0.72786177 0.73218143 0.69978402]
    Mean Score : 0.7219296939003501
    Std deviation : 0.012423143328469942
    
    
    =================================================
    
    
    [1mCross Validation Score RandomForestClassifier() :[0m
    
    Score : [0.69396552 0.9762419  0.96544276 0.96544276 0.98056156]
    Mean Score : 0.9163309004245178
    Std deviation : 0.11134201272142123
    
    
    =================================================
    
    
    [1mCross Validation Score AdaBoostClassifier() :[0m
    
    Score : [0.59267241 0.94168467 0.9287257  0.92008639 0.95464363]
    Mean Score : 0.8675625605124002
    Std deviation : 0.13794308567844243
    
    
    =================================================
    
    
    [1mCross Validation Score GradientBoostingClassifier() :[0m
    
    Score : [0.56465517 0.97192225 0.96544276 0.9524838  0.97192225]
    Mean Score : 0.8852852461458255
    Std deviation : 0.16047208936186597
    
    
    =================================================
    
    
    [1mCross Validation Score BaggingClassifier() :[0m
    
    Score : [0.64224138 0.9524838  0.95896328 0.92656587 0.95896328]
    Mean Score : 0.8878435242421986
    Std deviation : 0.12338090581100894
    
    
    =================================================
    

- On basis of maximum score in crossvalidation of Random Forest Classifier. we will apply Hyperparameter tuning on Random Forest model

## Hyper Parameter Tuning : GridSearchCV


```python
from sklearn.model_selection import GridSearchCV
parameter = {  'bootstrap': [True], 'max_depth': [5, 10,20,40,50, None], 
              'max_features': ['auto', 'log2'], 
              'criterion':['gini','entropy'],
              'n_estimators': [5, 10, 15 ,25,50,100]}
```


```python
GCV = GridSearchCV(RandomForestClassifier(),parameter,cv=5,n_jobs = -1,verbose=3)
GCV.fit(X_train,Y_train)
```

    Fitting 5 folds for each of 144 candidates, totalling 720 fits
    




    GridSearchCV(cv=5, estimator=RandomForestClassifier(), n_jobs=-1,
                 param_grid={'bootstrap': [True], 'criterion': ['gini', 'entropy'],
                             'max_depth': [5, 10, 20, 40, 50, None],
                             'max_features': ['auto', 'log2'],
                             'n_estimators': [5, 10, 15, 25, 50, 100]},
                 verbose=3)




```python
GCV.best_params_
```




    {'bootstrap': True,
     'criterion': 'entropy',
     'max_depth': 20,
     'max_features': 'log2',
     'n_estimators': 50}



# Final Model


```python
Final_mod = RandomForestClassifier(bootstrap=True,criterion='entropy',n_estimators= 50, max_depth=20 ,max_features='log2')
Final_mod.fit(X_train,Y_train)
y_pred=Final_mod.predict(X_test)
print('\033[1m'+'Accuracy Score :'+'\033[0m\n', accuracy_score(Y_test, y_pred))

```

    [1mAccuracy Score :[0m
     0.8901960784313725
    


```python
from sklearn.metrics import roc_auc_score
from sklearn.metrics import roc_curve

y_pred_prob = Final_mod.predict_proba(X_test)[:,1]
fpr, tpr, thresholds = roc_curve(Y_test,y_pred_prob)
plt.plot([0,1],[0,1], 'k--')
plt.plot(fpr, tpr, label='Random Forest Classifier')
plt.xlabel('False postive rate')
plt.ylabel('True postive rate')
plt.show()
auc_score = roc_auc_score(Y_test, Final_mod.predict(X_test))
print('\033[1m'+'Auc Score :'+'\033[0m\n',auc_score)
```


    
![png](output_112_0.png)
    


    [1mAuc Score :[0m
     0.8901533792650917
    

# Saving model


```python
import joblib
joblib.dump(Final_mod,'HR_Analytics_Final.pkl')
```




    ['HR_Analytics_Final.pkl']



## Predicting the Final Model


```python
prediction = Final_mod.predict(X_test)
```


```python
Actual = np.array(Y_test)
df_Pred = pd.DataFrame()
df_Pred["Predicted Values"] = prediction
df_Pred["Actual Values"] = Actual
df_Pred.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Predicted Values</th>
      <th>Actual Values</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python

```


```python

```


```python

```
